import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if os.path.dirname(os.path.abspath(__file__)) not in sys.path:
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, date, timedelta
import base64

from database import (
    get_production_logs_df,
    get_downtime_logs_df,
    get_plant_settings
)


# --- PERSISTENT AUTO-LOGIN ENGINE ---
# (Note: cookie_manager is already initialized at the top of this file!)
if not st.session_state.get("authenticated", False):
    cached_token = cookie_manager.get(cookie="formlabs_mes_token")
    if cached_token is not None:
        from database import get_all_users_df
        df_users = get_all_users_df()
        user_match = df_users[df_users["username"] == cached_token]

        if not user_match.empty:
            user_data = user_match.iloc[0]
            st.session_state["authenticated"] = True
            st.session_state["user_id"] = int(user_data["id"])
            st.session_state["user_role"] = user_data["role"]
            st.session_state["user_name"] = user_data["full_name"]
            st.session_state["user_shift"] = user_data.get("shift", "Shift 1")
            st.session_state["preferred_theme"] = user_data.get("preferred_theme", "Default Dark")
            time.sleep(0.5)
            st.rerun()

# 1. Initialize User & Role FIRST
current_user = st.session_state.get("user_name") or "Keagan C."

# Check Manager Role Security Gate
user_role = st.session_state.get("user_role") or "guest"
if user_role != "manager":
    st.error("🔒 Access Denied: This intelligence hub is restricted to Plant Management.")
    st.info("Please return to the main application and authenticate with Manager credentials.")
    st.stop()

# --- SETUP & LOGO ---
st.set_page_config(page_title="Analytics Engine | Formlabs MES", page_icon="🌌", layout="wide")


def get_base64_image(image_path):
    try:
        with open(image_path, "rb") as img_file:
            return base64.b64encode(img_file.read()).decode()
    except FileNotFoundError:
        return ""


logo_b64 = get_base64_image("assets/formlabs_logo.png")

# ===================== DYNAMIC THEME INJECTION =====================
try:
    from themes import THEMES
except ImportError:
    THEMES = {
        "Default Dark": "<style>.stApp { background-color: #02040A !important; color: #E2E8F0 !important; }</style>"}

active_theme = st.session_state.get("preferred_theme", "Default Dark")
if active_theme not in THEMES:
    active_theme = "Default Dark"

st.markdown(THEMES[active_theme], unsafe_allow_html=True)
# ===================================================================
# ===================== SIDEBAR: PROFILE & SETTINGS =====================
with st.sidebar:
    st.markdown("---")
    st.markdown(f"### 👤 {st.session_state.get('user_name', 'Manager')}")
    st.caption(
        f"Role: `{st.session_state.get('user_role', 'manager').upper()}` | Shift: `{st.session_state.get('user_shift', 'Shift 1')}`")

    st.markdown("<br>", unsafe_allow_html=True)
    st.markdown("**🎨 System Theme**")

    current = st.session_state.get("preferred_theme", "Default Dark")

    # Safely load THEMES dictionary
    try:
        from themes import THEMES
    except ImportError:
        THEMES = {"Default Dark": ""}

    if current not in THEMES:
        current = "Default Dark"

    chosen_theme = st.selectbox(
        "Select Interface Theme",
        list(THEMES.keys()),
        index=list(THEMES.keys()).index(current),
        label_visibility="collapsed",
        key="sidebar_theme_select"
    )

    if chosen_theme != current:
        from database import update_user_theme

        update_user_theme(st.session_state["user_id"], chosen_theme)
        st.session_state["preferred_theme"] = chosen_theme
        st.rerun()

    # --- HARD SECURITY GATE ---
    if not st.session_state.get("authenticated", False):
        st.warning("🔒 Unauthorized Access. Please log in.")
        st.switch_page("app.py")
        st.stop()

    st.markdown("<br>", unsafe_allow_html=True)

    if st.button("Log Out & Clear Device", type="primary", use_container_width=True, key="sidebar_logout_btn"):
        import extra_streamlit_components as stx

        cookie_manager = stx.CookieManager(key="logout_cookies")
        try:
            cookie_manager.delete("formlabs_mes_token")
        except KeyError:
            pass

        st.session_state["authenticated"] = False
        for key in ["user_role", "user_name", "user_id", "user_shift"]:
            if key in st.session_state:
                del st.session_state[key]

        import time

        time.sleep(0.5)
        st.switch_page("app.py")
# ===================== CRAZY MODERN CSS INJECTION =====================
st.markdown("""
<style>
    /* Hide default header for a cleaner app-like feel */
    header[data-testid="stHeader"] { visibility: hidden; }
    .block-container { padding-top: 1rem !important; }

    /* Glassmorphism KPI Cards */
    .glass-kpi {
        background: rgba(30, 41, 59, 0.25);
        backdrop-filter: blur(16px);
        -webkit-backdrop-filter: blur(16px);
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 16px;
        padding: 24px;
        position: relative;
        overflow: hidden;
        transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        box-shadow: 0 4px 30px rgba(0, 0, 0, 0.3);
    }

    /* Shimmer Effect on Hover */
    .glass-kpi::before {
        content: '';
        position: absolute;
        top: 0; left: -150%; width: 50%; height: 100%;
        background: linear-gradient(to right, transparent, rgba(255,255,255,0.05), transparent);
        transform: skewX(-25deg);
        transition: all 0.6s ease;
    }
    .glass-kpi:hover::before { left: 150%; }
    .glass-kpi:hover {
        transform: translateY(-8px);
        border-color: rgba(0, 210, 255, 0.4);
        box-shadow: 0 15px 35px rgba(0, 210, 255, 0.15);
    }

    /* Typography */
    .kpi-title {
        font-size: 0.8rem;
        font-weight: 800;
        color: #94A3B8;
        text-transform: uppercase;
        letter-spacing: 0.15em;
        margin-bottom: 8px;
    }
    .kpi-value {
        font-size: 3.2rem;
        font-weight: 900;
        background: linear-gradient(135deg, #00D2FF 0%, #3A7BD5 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        line-height: 1.1;
        margin-bottom: 12px;
    }
    .kpi-value-alt { background: linear-gradient(135deg, #F59E0B 0%, #EF4444 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
    .kpi-value-success { background: linear-gradient(135deg, #10B981 0%, #059669 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
    .kpi-value-purple { background: linear-gradient(135deg, #A855F7 0%, #6366F1 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }

    /* Tags */
    .trend-tag {
        display: inline-flex;
        align-items: center;
        padding: 4px 10px;
        border-radius: 20px;
        font-size: 0.75rem;
        font-weight: 800;
        letter-spacing: 0.05em;
    }
    .trend-up { background: rgba(16, 185, 129, 0.1); color: #10B981; border: 1px solid rgba(16, 185, 129, 0.2); }
    .trend-down { background: rgba(239, 68, 68, 0.1); color: #EF4444; border: 1px solid rgba(239, 68, 68, 0.2); }
    .trend-neutral { background: rgba(148, 163, 184, 0.1); color: #94A3B8; border: 1px solid rgba(148, 163, 184, 0.2); }
</style>
""", unsafe_allow_html=True)

# ===================== DATA ACQUISITION & PROCESSING =====================
from datetime import date, timedelta

today = date.today()
sevendays_ago = today - timedelta(days=7)
prev_sevendays_ago = sevendays_ago - timedelta(days=7)

# Fetch 14 days of data so we can calculate the week-over-week delta
df_logs = get_production_logs_df(start_date=prev_sevendays_ago, end_date=today)
df_dt = get_downtime_logs_df()
settings = get_plant_settings()

if not df_logs.empty:
    df_logs['date_obj'] = pd.to_datetime(df_logs['date']).dt.date
    df_logs['date_str'] = df_logs['date_obj'].astype(str)
else:
    df_logs = pd.DataFrame(columns=['date_obj', 'date_str', 'log_type', 'bottles_filled', 'scrap_empty', 'scrap_filled', 'resin_type'])

# Re-establish pour_df and pack_df for the rest of the script
pour_df = df_logs[df_logs["log_type"] == "Hourly Bottle Count"].copy()
pack_df = df_logs[df_logs["log_type"] == "Packing Count"].copy()

# Slice out the current 7 days
pour_7d = pour_df[pour_df['date_obj'] >= sevendays_ago]
dt_7d = df_dt[pd.to_datetime(df_dt['date']).dt.date >= sevendays_ago] if not df_dt.empty else pd.DataFrame()

# Math
total_poured_7d = pour_7d['bottles_filled'].sum() if not pour_7d.empty else 0
total_scrap_7d = (pour_7d['scrap_empty'].sum() + pour_7d['scrap_filled'].sum()) if not pour_7d.empty else 0
yield_7d = (total_poured_7d / (total_poured_7d + total_scrap_7d) * 100) if (total_poured_7d + total_scrap_7d) > 0 else 100.0
total_dt_mins = dt_7d['duration_min'].sum() if not dt_7d.empty else 0

# Previous 7 Days for Delta comparison
pour_prev7d = pour_df[(pour_df['date_obj'] >= prev_sevendays_ago) & (pour_df['date_obj'] < sevendays_ago)]
prev_poured = pour_prev7d['bottles_filled'].sum() if not pour_prev7d.empty else 0
pour_delta = total_poured_7d - prev_poured
pour_delta_pct = (pour_delta / prev_poured * 100) if prev_poured > 0 else 0

# --- LIVE SHIFT TICKER BAR ---
time_now = datetime.now()
s1_h, s1_m = map(int, settings["shift_1_start"].split(":"))
shift_1_start = time_now.replace(hour=s1_h, minute=s1_m, second=0)

# Calculate rapid live shift metrics
if time_now < shift_1_start:
    elapsed_hrs = (time_now - (shift_1_start - timedelta(days=1))).total_seconds() / 3600.0
else:
    elapsed_hrs = (time_now - shift_1_start).total_seconds() / 3600.0

total_shift_length = float(settings["shift_1_hours"]) + float(settings["shift_2_hours"])
elapsed_hrs = min(total_shift_length, max(0.1, elapsed_hrs))
remaining_hrs = max(0.0, total_shift_length - elapsed_hrs)

live_target_lph = float(settings.get("target_lph", 400.0))
live_today_poured = pour_df[pour_df['date_obj'] == today]['bottles_filled'].sum() if not pour_df.empty else 0

expected_right_now = live_target_lph * elapsed_hrs
live_rate = live_today_poured / elapsed_hrs
projected_daily = live_today_poured + ((live_rate if elapsed_hrs > 0.5 else live_target_lph) * remaining_hrs)

st.markdown(f"""
<div style="background: rgba(0, 210, 255, 0.05); border: 1px solid rgba(0, 210, 255, 0.2); border-radius: 12px; padding: 12px 24px; margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center;">
    <div>
        <div style="font-size: 0.7rem; font-weight: 800; color: #00D2FF; letter-spacing: 0.15em;">LIVE DAILY EXPECTATION (TICKING)</div>
        <div style="font-size: 1.5rem; font-weight: 900; color: #FFFFFF;">{expected_right_now:,.0f} L</div>
    </div>
    <div style="text-align: right;">
        <div style="font-size: 0.7rem; font-weight: 800; color: #A855F7; letter-spacing: 0.15em;">SELF-ADJUSTING DAILY PROJECTION</div>
        <div style="font-size: 1.5rem; font-weight: 900; color: #FFFFFF;">{projected_daily:,.0f} L</div>
    </div>
</div>
""", unsafe_allow_html=True)

# ===================== UI LAYOUT =====================
st.markdown(f"""
<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 30px;">
    <div style="display:flex; align-items:center; gap: 15px;">
        <img src="data:image/png;base64,{logo_b64}" style="height: 50px; object-fit: contain; filter: drop-shadow(0px 0px 8px rgba(0, 210, 255, 0.4));">
        <h1 style="margin:0; padding:0; font-size: 2.2rem; font-weight: 900; background: linear-gradient(to right, #FFFFFF, #94A3B8); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">NEXUS ANALYTICS</h1>
    </div>
    <div style="background: rgba(139, 92, 246, 0.1); border: 1px solid rgba(139, 92, 246, 0.3); padding: 8px 16px; border-radius: 8px; color: #A78BFA; font-weight: bold; letter-spacing: 0.1em; font-size: 0.8rem;">
        ROLLING 7-DAY INTELLIGENCE
    </div>
</div>
""", unsafe_allow_html=True)

# --- KPI ROW ---
k1, k2, k3, k4 = st.columns(4)

with k1:
    trend_class = "trend-up" if pour_delta_pct >= 0 else "trend-down"
    arrow = "▲" if pour_delta_pct >= 0 else "▼"
    st.markdown(f"""
    <div class="glass-kpi">
        <div class="kpi-title">Total Units Poured</div>
        <div class="kpi-value">{total_poured_7d:,.0f}</div>
        <div class="trend-tag {trend_class}">{arrow} {abs(pour_delta_pct):.1f}% vs Prev Week</div>
    </div>
    """, unsafe_allow_html=True)

with k2:
    st.markdown(f"""
    <div class="glass-kpi">
        <div class="kpi-title">Quality Yield (FPY)</div>
        <div class="kpi-value kpi-value-success">{yield_7d:.2f}%</div>
        <div class="trend-tag trend-neutral">Target: {settings.get('yield_target_pct', 99.0)}%</div>
    </div>
    """, unsafe_allow_html=True)

with k3:
    st.markdown(f"""
    <div class="glass-kpi">
        <div class="kpi-title">Total Scrap Volume</div>
        <div class="kpi-value kpi-value-alt">{total_scrap_7d:,.0f}</div>
        <div class="trend-tag trend-down">Lost Units</div>
    </div>
    """, unsafe_allow_html=True)

with k4:
    dt_hours = total_dt_mins / 60
    st.markdown(f"""
    <div class="glass-kpi">
        <div class="kpi-title">Accumulated Downtime</div>
        <div class="kpi-value kpi-value-purple">{dt_hours:.1f}h</div>
        <div class="trend-tag trend-neutral">{total_dt_mins} Minutes Logged</div>
    </div>
    """, unsafe_allow_html=True)

st.markdown("<br>", unsafe_allow_html=True)

# --- CHARTS ROW 1 ---
c1, c2 = st.columns((2, 1))

# Chart Theming configuration to make Plotly blend into the Glassmorphism CSS
chart_layout = dict(
    paper_bgcolor='rgba(0,0,0,0)',
    plot_bgcolor='rgba(0,0,0,0)',
    font=dict(color='#94A3B8', family="sans-serif"),
    margin=dict(t=40, b=20, l=20, r=20),
    xaxis=dict(showgrid=False, zeroline=False),
    yaxis=dict(showgrid=True, gridcolor='rgba(255,255,255,0.05)', zeroline=False)
)

with c1:
    st.markdown("<h4 style='color:#E2E8F0;'>📈 Production Velocity Stream</h4>", unsafe_allow_html=True)
    if not pour_7d.empty:
        trend_df = pour_7d.groupby("date_str")["bottles_filled"].sum().reset_index()
        fig_line = px.area(trend_df, x="date_str", y="bottles_filled", markers=True)
        # Apply intense gradient styling
        fig_line.update_traces(
            line=dict(color='#00D2FF', width=4),
            marker=dict(size=8, color='#FFFFFF', line=dict(width=2, color='#00D2FF')),
            fillcolor='rgba(0, 210, 255, 0.1)'
        )
        fig_line.update_layout(**chart_layout)
        st.plotly_chart(fig_line, use_container_width=True)
    else:
        st.info("No pouring data available for the last 7 days.")

with c2:
    st.markdown("<h4 style='color:#E2E8F0;'>🧪 Formulation Output</h4>", unsafe_allow_html=True)
    if not pour_7d.empty:
        resin_grp = pour_7d.groupby("resin_type")["bottles_filled"].sum().reset_index()
        fig_donut = px.pie(resin_grp, names="resin_type", values="bottles_filled", hole=0.7)
        fig_donut.update_traces(
            hoverinfo='label+percent',
            textinfo='none',
            marker=dict(line=dict(color='#02040A', width=2))
        )
        fig_donut.update_layout(
            **chart_layout,
            showlegend=True,
            legend=dict(orientation="h", yanchor="bottom", y=-0.2, xanchor="center", x=0.5)
        )
        # Add total center text
        fig_donut.add_annotation(text=f"<b>{total_poured_7d:,.0f}</b><br>Total", x=0.5, y=0.5, font_size=20,
                                 showarrow=False, font_color="#FFFFFF")
        st.plotly_chart(fig_donut, use_container_width=True)

st.markdown("---")

# --- CHARTS ROW 2 ---
d1, d2 = st.columns((1, 2))

with d1:
    st.markdown("<h4 style='color:#E2E8F0;'>⚠️ Downtime Pareto</h4>", unsafe_allow_html=True)
    if not dt_7d.empty:
        dt_grp = dt_7d.groupby("reason")["duration_min"].sum().reset_index().sort_values("duration_min", ascending=True)
        fig_bar = px.bar(dt_grp, x="duration_min", y="reason", orientation='h')
        fig_bar.update_traces(marker_color='#A855F7', marker_line_color='#D8B4FE', marker_line_width=1.5, opacity=0.8)
        fig_bar.update_layout(**chart_layout)
        fig_bar.update_yaxes(title="")
        fig_bar.update_xaxes(title="Minutes")
        st.plotly_chart(fig_bar, use_container_width=True)
    else:
        st.success("No downtime events logged in the last 7 days! 🎉")

with d2:
    st.markdown("<h4 style='color:#E2E8F0;'>👥 Operator Contribution Matrix</h4>", unsafe_allow_html=True)
    if not pour_df.empty:
        # Get the top 5 operators over the whole dataset for a wider matrix
        op_matrix = pour_df.groupby(["operator_name", "date_str"])["bottles_filled"].sum().reset_index()
        top_ops = op_matrix.groupby("operator_name")["bottles_filled"].sum().nlargest(5).index
        op_matrix = op_matrix[op_matrix["operator_name"].isin(top_ops)]

        fig_heat = go.Figure(data=go.Heatmap(
            z=op_matrix['bottles_filled'],
            x=op_matrix['date_str'],
            y=op_matrix['operator_name'],
            colorscale='Tealgrn',
            hoverongaps=False,
            xgap=3, ygap=3
        ))
        fig_heat.update_layout(**chart_layout)
        st.plotly_chart(fig_heat, use_container_width=True)
    else:
        st.info("Insufficient data for matrix.")