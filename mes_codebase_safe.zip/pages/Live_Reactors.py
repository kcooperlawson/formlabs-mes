import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import streamlit as st
import pandas as pd
from database import (
    get_assigned_runs_df,
    get_all_resin_specs_df,
    calculate_logged_units_for_resin,
    get_all_reactors_df,
    add_reactor,
    delete_reactor,
    update_reactor_config,
    get_active_pumps
)
import base64

def get_base64_image(image_path):
    try:
        with open(image_path, "rb") as img_file:
            return base64.b64encode(img_file.read()).decode()
    except FileNotFoundError:
        return ""

logo_b64 = get_base64_image("assets/formlabs_logo.png")

st.set_page_config(page_title="Live Reactor Fleet SCADA | Formlabs MES", page_icon="🛢️", layout="wide")
st.logo("assets/formlabs_logo.png")

# ===================== DYNAMIC THEME INJECTION =====================
try:
    from themes import THEMES
except ImportError:
    THEMES = {"Default Dark": "<style>.stApp { background-color: #02040A !important; color: #E2E8F0 !important; }</style>"}

active_theme = st.session_state.get("preferred_theme", "Default Dark")
if active_theme not in THEMES:
    active_theme = "Default Dark"

st.markdown(THEMES[active_theme], unsafe_allow_html=True)
# ===================================================================

@st.fragment(run_every="10s")
def auto_refresh_reactors():
    pass

auto_refresh_reactors()

# --- PERSISTENT AUTO-LOGIN ENGINE ---
# (Note: cookie_manager is already initialized at the top of this file!)
if not st.session_state.get("authenticated", False):
    cached_token = cookie_manager.get(cookie="formlabs_mes_token")
    if cached_token is not None:
        from database import get_all_users_df
        df_users = get_all_users_df()
        user_match = df_users[df_users["username"] == cached_token]

        if not user_match.empty:
            user_data = user_match.iloc[0]
            st.session_state["authenticated"] = True
            st.session_state["user_id"] = int(user_data["id"])
            st.session_state["user_role"] = user_data["role"]
            st.session_state["user_name"] = user_data["full_name"]
            st.session_state["user_shift"] = user_data.get("shift", "Shift 1")
            st.session_state["preferred_theme"] = user_data.get("preferred_theme", "Default Dark")
            time.sleep(0.5)
            st.rerun()

# --- HARD SECURITY GATE ---
if not st.session_state.get("authenticated", False):
    st.warning("🔒 Unauthorized Access. Please log in.")
    st.switch_page("app.py")
    st.stop()


# 1. Initialize User & Role FIRST
current_user = st.session_state.get("user_name") or "Keagan C."

# ===================== DYNAMIC THEME INJECTION =====================
try:
    from themes import THEMES
except ImportError:
    THEMES = {"Default Dark": "<style>.stApp { background-color: #02040A !important; color: #E2E8F0 !important; }</style>"}

active_theme = st.session_state.get("preferred_theme", "Default Dark")
if active_theme not in THEMES:
    active_theme = "Default Dark"

st.markdown(THEMES[active_theme], unsafe_allow_html=True)
# ===================================================================

# ===================== SIDEBAR: PROFILE & SETTINGS =====================
with st.sidebar:
    st.markdown("---")
    st.markdown(f"### 👤 {st.session_state.get('user_name', 'Manager')}")
    st.caption(
        f"Role: `{st.session_state.get('user_role', 'manager').upper()}` | Shift: `{st.session_state.get('user_shift', 'Shift 1')}`")

    st.markdown("<br>", unsafe_allow_html=True)
    st.markdown("**🎨 System Theme**")

    current = st.session_state.get("preferred_theme", "Default Dark")

    # Safely load THEMES dictionary
    try:
        from themes import THEMES
    except ImportError:
        THEMES = {"Default Dark": ""}

    if current not in THEMES:
        current = "Default Dark"

    chosen_theme = st.selectbox(
        "Select Interface Theme",
        list(THEMES.keys()),
        index=list(THEMES.keys()).index(current),
        label_visibility="collapsed",
        key="sidebar_theme_select"
    )

    if chosen_theme != current:
        from database import update_user_theme

        update_user_theme(st.session_state["user_id"], chosen_theme)
        st.session_state["preferred_theme"] = chosen_theme
        st.rerun()

    st.markdown("<br>", unsafe_allow_html=True)

    if st.button("Log Out & Clear Device", type="primary", use_container_width=True, key="sidebar_logout_btn"):
        import extra_streamlit_components as stx

        cookie_manager = stx.CookieManager(key="logout_cookies")
        try:
            cookie_manager.delete("formlabs_mes_token")
        except KeyError:
            pass

        st.session_state["authenticated"] = False
        for key in ["user_role", "user_name", "user_id", "user_shift"]:
            if key in st.session_state:
                del st.session_state[key]

        import time

        time.sleep(0.5)
        st.switch_page("app.py")


st.markdown(f"""
<div class="brand-header">
    <div style="display:flex; align-items:center;">
        <img src="data:image/png;base64,{logo_b64}" style="height: 60px; object-fit: contain;">
        <div style="font-size:1.4rem; font-weight:900; color:#FFFFFF; margin-left:15px;">🛢️ REAL-TIME REACTOR FLEET</div>
    </div>
    <span style="background: rgba(16, 185, 129, 0.15); color: #10B981; border: 1px solid #10B981; border-radius: 20px; padding: 4px 12px; font-weight: 800;">● LIVE SENSOR SYNC</span>
</div>
""", unsafe_allow_html=True)

df_reactors = get_all_reactors_df()
df_runs = get_assigned_runs_df()
specs_df = get_all_resin_specs_df("ALL")

spec_dict = {}
if not specs_df.empty:
    for _, r in specs_df.iterrows():
        spec_dict[f"{str(r['cartridge_type']).strip().lower()}_{str(r['resin_name']).strip().lower()}"] = float(r["actual_spec_g"])

all_resins = ["None"] + sorted(specs_df["resin_name"].unique().tolist()) if not specs_df.empty else ["None"]
all_pumps = ["None"] + get_active_pumps()

if st.session_state.get("user_role") == "manager":
    with st.expander("⚙️ Manage Permanent Reactor Fleet", expanded=False):
        c1, c2 = st.columns([1.5, 2.5])
        with c1:
            st.markdown("**➕ Add New Permanent Reactor**")
            with st.form("add_reactor_form", clear_on_submit=True):
                new_name = st.text_input("Reactor Name (e.g. Tank C-5000)")
                new_cap = st.number_input("Max Capacity (Liters)", value=5000, step=500)
                if st.form_submit_button("Add Permanent Reactor", type="primary", use_container_width=True):
                    if new_name.strip():
                        add_reactor(new_name, int(new_cap))
                        st.rerun()
        with c2:
            st.markdown("**🏭 Permanent Fleet Registration**")
            st.caption("Reactors are permanent physical tanks. They will automatically fill and empty as you dispatch or complete Work Orders.")
            if not df_reactors.empty:
                for _, r in df_reactors.iterrows():
                    r_id = r['id']
                    col_r1, col_r2 = st.columns([4, 1])
                    
                    col_r1.markdown(f"<div style='margin-top:8px;'><b>🛢️ {r['reactor_name']}</b> <span style='color:#94A3B8; font-size:0.9rem;'>({r['max_capacity_l']:,} L Capacity)</span></div>", unsafe_allow_html=True)
                    
                    if col_r2.button("🗑️ Remove", key=f"del_{r_id}"):
                        delete_reactor(r_id)
                        st.rerun()
                    st.markdown("<hr style='margin: 5px 0; border-color: #1E2B45;'>", unsafe_allow_html=True)
            else:
                st.caption("No permanent reactors added yet.")

st.markdown("---")

if not df_reactors.empty:
    cols_per_row = 4
    for i in range(0, len(df_reactors), cols_per_row):
        row_reactors = df_reactors.iloc[i:i+cols_per_row]
        tank_cols = st.columns(cols_per_row)

        for j, (_, reactor) in enumerate(row_reactors.iterrows()):
            capacity_l = float(reactor["max_capacity_l"])
            r_name = reactor["reactor_name"]
            r_resin = reactor.get("current_resin")
            r_pump = reactor.get("assigned_pump")

            # Check if there happens to be a formal active run mapping to this tank
            active_run = None
            if not df_runs.empty:
                matches = df_runs[(df_runs["reactor_id"] == r_name) & (df_runs["status"].isin(["Active", "Pouring"]))]
                if not matches.empty:
                    active_run = matches.iloc[0]

            if r_resin and r_resin != "None":
                target_pump = r_pump if (r_pump and r_pump != "None") else ""
                
                # Pull active run lot if present to ensure exact batch matching
                target_lot = str(active_run.get("lot_number", "")) if active_run is not None else ""

                # Calculate fill level dynamically from database logs
                current_poured_units = float(calculate_logged_units_for_resin(
                    resin_name=r_resin, 
                    pump_station=target_pump,
                    lot_number=target_lot
                ))

                # If an active run exists, pull exact metadata from it. Otherwise assume V2 default format.
                if active_run is not None:
                    c_type = str(active_run.get("cartridge_type", "V2")).strip()
                    op = str(active_run.get("assigned_operator", "Active Run")).strip()
                else:
                    c_type = "V2"
                    op = "Manual Floor WIP"

                vol_mult = 5.0 if "RPS" in c_type.upper() else (0.124 if "PIGMENT" in c_type.upper() else 1.0)
                poured_l = current_poured_units * vol_mult
                remaining_l = max(0.0, capacity_l - poured_l)
                fill_pct = min(100.0, (remaining_l / capacity_l) * 100.0) if capacity_l > 0 else 100.0
                
                lookup_key = f"{str(c_type).lower()}_{str(r_resin).lower()}"
                unit_g = spec_dict.get(lookup_key, 5500.0 if "RPS" in c_type.upper() else 1110.0)
                unit_kg = unit_g / 1000.0

                total_capacity_kg = (capacity_l / vol_mult) * unit_kg if vol_mult > 0 else 0.0
                poured_kg = current_poured_units * unit_kg
                remaining_kg = max(0.0, total_capacity_kg - poured_kg)

                tank_color = "linear-gradient(0deg, #EF4444 0%, #F87171 100%)" if fill_pct < 10 else "linear-gradient(0deg, #3B82F6 0%, #00D2FF 100%)"
                status_html = f"<span style='color:#00D2FF; font-weight:800;'>{r_resin}</span><br><span style='color:#64748B; font-size:0.7rem;'>Station: {target_pump if target_pump else 'Any'} | Op: {op}</span>"
                rem_display = f"{remaining_l:,.0f} L"
            else:
                fill_pct = 0.0
                tank_color = "transparent"
                status_html = f"<span style='color:#64748B; font-weight:800;'>IDLE / EMPTY</span><br><span style='color:#334155; font-size:0.7rem;'>Available for Setup</span>"
                rem_display = "0 L"
                remaining_kg = 0

            # --- DYNAMIC VISUAL STYLING BASED ON TANK CAPACITY ---
            if capacity_l >= 5000:
                # Tall 30ft cone-bottom on heavy metal stand
                tank_style = "width: 140px; height: 320px; margin: 0 auto; border: 3px solid #94A3B8; border-radius: 10px 10px 50% 50% / 10px 10px 15% 15%;"
                # Stand sits slightly behind and overlaps the cone bottom
                stand_html = '<div style="width: 144px; height: 60px; margin: -20px auto 0 auto; border: 6px solid #475569; border-top: none; position: relative; z-index: 1;"></div><div style="width: 156px; height: 8px; margin: 0 auto; background: #475569; border-radius: 3px;"></div>'
            elif capacity_l >= 3000:
                # Medium 15ft cone-bottom on standard metal stand
                tank_style = "width: 180px; height: 220px; margin: 0 auto; border: 3px solid #94A3B8; border-radius: 10px 10px 50% 50% / 10px 10px 22% 22%;"
                stand_html = '<div style="width: 184px; height: 50px; margin: -20px auto 0 auto; border: 5px solid #475569; border-top: none; position: relative; z-index: 1;"></div><div style="width: 196px; height: 8px; margin: 0 auto; background: #475569; border-radius: 3px;"></div>'
            else:
                # 1000L IBC Tote with Blue Plastic Frame and Pallet Base
                tank_style = "width: 220px; height: 180px; margin: 0 auto; border: 10px solid #2563EB; border-radius: 12px;"
                stand_html = '<div style="width: 220px; height: 16px; margin: 4px auto 0 auto; background: #1E3A8A; border-radius: 4px;"></div>'

            html_card = (
                f'<div style="width:100%; margin-bottom:24px;">'
                f'<div style="text-align:center; color:#FFFFFF; font-weight:800; margin-bottom:12px; font-size:1.1rem;">{r_name}</div>'
                f'<div style="{tank_style} background:#060B14; position:relative; overflow:hidden; box-shadow:inset 0 5px 15px rgba(0,0,0,0.8); z-index: 2;">'
                f'<div style="position:absolute; bottom:0; width:100%; height:{fill_pct}%; background:{tank_color}; transition:height 1s ease-in-out; opacity:0.85; border-top:2px solid rgba(255,255,255,0.8);"></div>'
                f'<div style="position:absolute; top:40%; width:100%; text-align:center; font-size:1.5rem; font-weight:900; color:#FFFFFF; text-shadow:2px 2px 6px #000; z-index: 3;">{fill_pct:.1f}%</div>'
                f'</div>'
                f'{stand_html}'
                f'<div style="text-align:center; background:linear-gradient(180deg, #0D1627 0%, #080D1A 100%); border:1px solid #00D2FF; border-radius:8px; padding:8px; margin-top:16px;">'
                f'<div style="font-size:0.6rem; font-weight:800; color:#94A3B8; letter-spacing:0.1em;">REMAINING IN TANK</div>'
                f'<div style="font-size:1.05rem; font-weight:900; color:#FFFFFF; margin-top:2px;">{rem_display} <span style="font-size:0.7rem; color:#64748B;">({remaining_kg:,.0f} kg)</span></div>'
                f'</div>'
                f'<div style="text-align:center; background-color:#0F172A; border:1px solid #1E2B45; border-radius:6px; padding:6px; margin-top:6px;">'
                f'{status_html}'
                f'</div>'
                f'</div>'
            )

            with tank_cols[j]:
                st.markdown(html_card, unsafe_allow_html=True)
else:
    st.info("No active physical reactors allocated by management. Add them in the settings menu above.")