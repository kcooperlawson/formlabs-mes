--
-- PostgreSQL database dump
--

\restrict wg8o3RyU0cDIFNBgbbhcEmpxSPXO5S8IdSefX0LOz2g7NKwwnhv2QY8NwnFZbY4

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.sheet_targets DROP CONSTRAINT IF EXISTS sheet_targets_owner_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.reactors DROP CONSTRAINT IF EXISTS reactors_current_resin_id_fkey;
ALTER TABLE IF EXISTS ONLY public.reactors DROP CONSTRAINT IF EXISTS reactors_assigned_pump_id_fkey;
ALTER TABLE IF EXISTS ONLY public.production_logs DROP CONSTRAINT IF EXISTS production_logs_resin_spec_id_fkey;
ALTER TABLE IF EXISTS ONLY public.production_logs DROP CONSTRAINT IF EXISTS production_logs_pump_station_id_fkey;
ALTER TABLE IF EXISTS ONLY public.production_logs DROP CONSTRAINT IF EXISTS production_logs_operator_id_fkey;
ALTER TABLE IF EXISTS ONLY public.lot_verifications DROP CONSTRAINT IF EXISTS lot_verifications_resin_spec_id_fkey;
ALTER TABLE IF EXISTS ONLY public.lot_verifications DROP CONSTRAINT IF EXISTS lot_verifications_pump_station_id_fkey;
ALTER TABLE IF EXISTS ONLY public.lot_verifications DROP CONSTRAINT IF EXISTS lot_verifications_production_log_id_fkey;
ALTER TABLE IF EXISTS ONLY public.lot_verifications DROP CONSTRAINT IF EXISTS lot_verifications_operator_id_fkey;
ALTER TABLE IF EXISTS ONLY public.floor_messages DROP CONSTRAINT IF EXISTS floor_messages_sender_id_fkey;
ALTER TABLE IF EXISTS ONLY public.floor_messages DROP CONSTRAINT IF EXISTS floor_messages_operator_id_fkey;
ALTER TABLE IF EXISTS ONLY public.daily_checklists DROP CONSTRAINT IF EXISTS fk_daily_checklists_pump_station_id;
ALTER TABLE IF EXISTS ONLY public.downtime_logs DROP CONSTRAINT IF EXISTS downtime_logs_pump_station_id_fkey;
ALTER TABLE IF EXISTS ONLY public.downtime_logs DROP CONSTRAINT IF EXISTS downtime_logs_operator_id_fkey;
ALTER TABLE IF EXISTS ONLY public.devices DROP CONSTRAINT IF EXISTS devices_reactor_id_fkey;
ALTER TABLE IF EXISTS ONLY public.devices DROP CONSTRAINT IF EXISTS devices_pump_station_id_fkey;
ALTER TABLE IF EXISTS ONLY public.device_tag_maps DROP CONSTRAINT IF EXISTS device_tag_maps_device_id_fkey;
ALTER TABLE IF EXISTS ONLY public.device_readings DROP CONSTRAINT IF EXISTS device_readings_device_id_fkey;
ALTER TABLE IF EXISTS ONLY public.daily_checklists DROP CONSTRAINT IF EXISTS daily_checklists_operator_id_fkey;
ALTER TABLE IF EXISTS ONLY public.cleanliness_audits DROP CONSTRAINT IF EXISTS cleanliness_audits_resin_spec_id_fkey;
ALTER TABLE IF EXISTS ONLY public.cleanliness_audits DROP CONSTRAINT IF EXISTS cleanliness_audits_pump_station_id_fkey;
ALTER TABLE IF EXISTS ONLY public.cleanliness_audits DROP CONSTRAINT IF EXISTS cleanliness_audits_operator_id_fkey;
ALTER TABLE IF EXISTS ONLY public.assigned_runs DROP CONSTRAINT IF EXISTS assigned_runs_resin_spec_id_fkey;
ALTER TABLE IF EXISTS ONLY public.assigned_runs DROP CONSTRAINT IF EXISTS assigned_runs_pump_station_id_fkey;
ALTER TABLE IF EXISTS ONLY public.assigned_runs DROP CONSTRAINT IF EXISTS assigned_runs_operator_id_fkey;
DROP INDEX IF EXISTS public.ix_user_sessions_user_id;
DROP INDEX IF EXISTS public.ix_user_sessions_token;
DROP INDEX IF EXISTS public.ix_suggestions_timestamp;
DROP INDEX IF EXISTS public.ix_production_logs_weight_status;
DROP INDEX IF EXISTS public.ix_production_logs_verify_status;
DROP INDEX IF EXISTS public.ix_production_logs_timestamp;
DROP INDEX IF EXISTS public.ix_production_logs_pump_station;
DROP INDEX IF EXISTS public.ix_production_logs_operator_name;
DROP INDEX IF EXISTS public.ix_production_logs_date;
DROP INDEX IF EXISTS public.ix_lot_verifications_timestamp;
DROP INDEX IF EXISTS public.ix_lot_verifications_result;
DROP INDEX IF EXISTS public.ix_lot_verifications_resin_spec_id;
DROP INDEX IF EXISTS public.ix_lot_verifications_pump_station_id;
DROP INDEX IF EXISTS public.ix_lot_verifications_pump_station;
DROP INDEX IF EXISTS public.ix_lot_verifications_production_log_id;
DROP INDEX IF EXISTS public.ix_lot_verifications_operator_name;
DROP INDEX IF EXISTS public.ix_lot_verifications_operator_id;
DROP INDEX IF EXISTS public.ix_lot_verifications_date;
DROP INDEX IF EXISTS public.ix_floor_messages_timestamp;
DROP INDEX IF EXISTS public.ix_floor_messages_operator_name;
DROP INDEX IF EXISTS public.ix_downtime_logs_timestamp;
DROP INDEX IF EXISTS public.ix_downtime_logs_date;
DROP INDEX IF EXISTS public.ix_devices_reactor_id;
DROP INDEX IF EXISTS public.ix_devices_pump_station_id;
DROP INDEX IF EXISTS public.ix_device_tag_maps_device_id;
DROP INDEX IF EXISTS public.ix_device_readings_timestamp;
DROP INDEX IF EXISTS public.ix_device_readings_metric;
DROP INDEX IF EXISTS public.ix_device_readings_device_id;
DROP INDEX IF EXISTS public.ix_daily_checklists_pump_station_id;
DROP INDEX IF EXISTS public.ix_daily_checklists_pump_station;
DROP INDEX IF EXISTS public.ix_daily_checklists_operator_name;
DROP INDEX IF EXISTS public.ix_daily_checklists_date;
DROP INDEX IF EXISTS public.ix_cleanliness_audits_timestamp;
DROP INDEX IF EXISTS public.ix_cleanliness_audits_date;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_username_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.user_sessions DROP CONSTRAINT IF EXISTS user_sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.suggestions DROP CONSTRAINT IF EXISTS suggestions_pkey;
ALTER TABLE IF EXISTS ONLY public.sheet_targets DROP CONSTRAINT IF EXISTS sheet_targets_pkey;
ALTER TABLE IF EXISTS ONLY public.resin_specs DROP CONSTRAINT IF EXISTS resin_specs_pkey;
ALTER TABLE IF EXISTS ONLY public.reactors DROP CONSTRAINT IF EXISTS reactors_reactor_name_key;
ALTER TABLE IF EXISTS ONLY public.reactors DROP CONSTRAINT IF EXISTS reactors_pkey;
ALTER TABLE IF EXISTS ONLY public.pump_stations DROP CONSTRAINT IF EXISTS pump_stations_station_name_key;
ALTER TABLE IF EXISTS ONLY public.pump_stations DROP CONSTRAINT IF EXISTS pump_stations_pkey;
ALTER TABLE IF EXISTS ONLY public.production_logs DROP CONSTRAINT IF EXISTS production_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.plant_settings DROP CONSTRAINT IF EXISTS plant_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.lot_verifications DROP CONSTRAINT IF EXISTS lot_verifications_pkey;
ALTER TABLE IF EXISTS ONLY public.floor_messages DROP CONSTRAINT IF EXISTS floor_messages_pkey;
ALTER TABLE IF EXISTS ONLY public.downtime_reasons DROP CONSTRAINT IF EXISTS downtime_reasons_reason_name_key;
ALTER TABLE IF EXISTS ONLY public.downtime_reasons DROP CONSTRAINT IF EXISTS downtime_reasons_pkey;
ALTER TABLE IF EXISTS ONLY public.downtime_logs DROP CONSTRAINT IF EXISTS downtime_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.devices DROP CONSTRAINT IF EXISTS devices_pkey;
ALTER TABLE IF EXISTS ONLY public.devices DROP CONSTRAINT IF EXISTS devices_device_name_key;
ALTER TABLE IF EXISTS ONLY public.device_tag_maps DROP CONSTRAINT IF EXISTS device_tag_maps_pkey;
ALTER TABLE IF EXISTS ONLY public.device_readings DROP CONSTRAINT IF EXISTS device_readings_pkey;
ALTER TABLE IF EXISTS ONLY public.daily_checklists DROP CONSTRAINT IF EXISTS daily_checklists_pkey;
ALTER TABLE IF EXISTS ONLY public.cleanliness_audits DROP CONSTRAINT IF EXISTS cleanliness_audits_pkey;
ALTER TABLE IF EXISTS ONLY public.assigned_runs DROP CONSTRAINT IF EXISTS assigned_runs_pkey;
ALTER TABLE IF EXISTS ONLY public.alembic_version DROP CONSTRAINT IF EXISTS alembic_version_pkc;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_sessions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.suggestions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.sheet_targets ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.resin_specs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.reactors ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.pump_stations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.production_logs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.plant_settings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.lot_verifications ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.floor_messages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.downtime_reasons ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.downtime_logs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.devices ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.device_tag_maps ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.device_readings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.daily_checklists ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.cleanliness_audits ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.assigned_runs ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.user_sessions_id_seq;
DROP TABLE IF EXISTS public.user_sessions;
DROP SEQUENCE IF EXISTS public.suggestions_id_seq;
DROP TABLE IF EXISTS public.suggestions;
DROP SEQUENCE IF EXISTS public.sheet_targets_id_seq;
DROP TABLE IF EXISTS public.sheet_targets;
DROP SEQUENCE IF EXISTS public.resin_specs_id_seq;
DROP TABLE IF EXISTS public.resin_specs;
DROP SEQUENCE IF EXISTS public.reactors_id_seq;
DROP TABLE IF EXISTS public.reactors;
DROP SEQUENCE IF EXISTS public.pump_stations_id_seq;
DROP TABLE IF EXISTS public.pump_stations;
DROP SEQUENCE IF EXISTS public.production_logs_id_seq;
DROP TABLE IF EXISTS public.production_logs;
DROP SEQUENCE IF EXISTS public.plant_settings_id_seq;
DROP TABLE IF EXISTS public.plant_settings;
DROP SEQUENCE IF EXISTS public.lot_verifications_id_seq;
DROP TABLE IF EXISTS public.lot_verifications;
DROP SEQUENCE IF EXISTS public.floor_messages_id_seq;
DROP TABLE IF EXISTS public.floor_messages;
DROP SEQUENCE IF EXISTS public.downtime_reasons_id_seq;
DROP TABLE IF EXISTS public.downtime_reasons;
DROP SEQUENCE IF EXISTS public.downtime_logs_id_seq;
DROP TABLE IF EXISTS public.downtime_logs;
DROP SEQUENCE IF EXISTS public.devices_id_seq;
DROP TABLE IF EXISTS public.devices;
DROP SEQUENCE IF EXISTS public.device_tag_maps_id_seq;
DROP TABLE IF EXISTS public.device_tag_maps;
DROP SEQUENCE IF EXISTS public.device_readings_id_seq;
DROP TABLE IF EXISTS public.device_readings;
DROP SEQUENCE IF EXISTS public.daily_checklists_id_seq;
DROP TABLE IF EXISTS public.daily_checklists;
DROP SEQUENCE IF EXISTS public.cleanliness_audits_id_seq;
DROP TABLE IF EXISTS public.cleanliness_audits;
DROP SEQUENCE IF EXISTS public.assigned_runs_id_seq;
DROP TABLE IF EXISTS public.assigned_runs;
DROP TABLE IF EXISTS public.alembic_version;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: assigned_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assigned_runs (
    id integer NOT NULL,
    created_at timestamp without time zone,
    reactor_id character varying(50),
    reactor_size_l integer,
    resin_type character varying(100) NOT NULL,
    cartridge_type character varying(20),
    target_units integer NOT NULL,
    current_units integer,
    assigned_operator character varying(100) NOT NULL,
    pump_station character varying(50) NOT NULL,
    status character varying(20),
    lot_number character varying(50),
    notes text,
    run_type character varying(20) DEFAULT 'Pouring'::character varying,
    resin_spec_id integer,
    operator_id integer,
    pump_station_id integer
);


--
-- Name: assigned_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.assigned_runs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: assigned_runs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.assigned_runs_id_seq OWNED BY public.assigned_runs.id;


--
-- Name: cleanliness_audits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cleanliness_audits (
    id integer NOT NULL,
    "timestamp" timestamp without time zone,
    date date,
    audit_type character varying(50) NOT NULL,
    operator_name character varying(100) NOT NULL,
    pump_station character varying(50) NOT NULL,
    shift character varying(20),
    resin_type character varying(100),
    image_filename character varying(255),
    is_spill character varying(10),
    notes text,
    operator_id integer,
    pump_station_id integer,
    resin_spec_id integer
);


--
-- Name: cleanliness_audits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cleanliness_audits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cleanliness_audits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cleanliness_audits_id_seq OWNED BY public.cleanliness_audits.id;


--
-- Name: daily_checklists; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.daily_checklists (
    id integer NOT NULL,
    date date,
    operator_name character varying(100) NOT NULL,
    shift character varying(20) NOT NULL,
    "timestamp" timestamp without time zone,
    operator_id integer,
    pump_station character varying(50),
    pump_station_id integer
);


--
-- Name: daily_checklists_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.daily_checklists_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: daily_checklists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.daily_checklists_id_seq OWNED BY public.daily_checklists.id;


--
-- Name: device_readings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.device_readings (
    id integer NOT NULL,
    device_id integer NOT NULL,
    "timestamp" timestamp without time zone,
    metric character varying(50) NOT NULL,
    value_numeric double precision,
    value_text character varying(255)
);


--
-- Name: device_readings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.device_readings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: device_readings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.device_readings_id_seq OWNED BY public.device_readings.id;


--
-- Name: device_tag_maps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.device_tag_maps (
    id integer NOT NULL,
    device_id integer NOT NULL,
    raw_tag character varying(255) NOT NULL,
    canonical_metric character varying(50) NOT NULL,
    data_type character varying(20) DEFAULT 'float'::character varying,
    scale_factor double precision DEFAULT '1'::double precision,
    unit character varying(20)
);


--
-- Name: device_tag_maps_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.device_tag_maps_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: device_tag_maps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.device_tag_maps_id_seq OWNED BY public.device_tag_maps.id;


--
-- Name: devices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.devices (
    id integer NOT NULL,
    device_name character varying(100) NOT NULL,
    device_role character varying(30) DEFAULT 'filling_station'::character varying NOT NULL,
    protocol character varying(30) NOT NULL,
    connection_json text DEFAULT '{}'::text NOT NULL,
    poll_interval_s double precision DEFAULT '5'::double precision,
    is_enabled boolean DEFAULT true NOT NULL,
    pump_station_id integer,
    reactor_id integer,
    status character varying(20) DEFAULT 'Unknown'::character varying,
    last_seen_at timestamp without time zone,
    last_error text,
    notes text,
    created_at timestamp without time zone
);


--
-- Name: devices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.devices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: devices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.devices_id_seq OWNED BY public.devices.id;


--
-- Name: downtime_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.downtime_logs (
    id integer NOT NULL,
    "timestamp" timestamp without time zone,
    date date,
    operator_name character varying(100) NOT NULL,
    pump_station character varying(50) NOT NULL,
    shift character varying(20),
    reason character varying(100) NOT NULL,
    duration_min integer NOT NULL,
    notes text,
    operator_id integer,
    pump_station_id integer
);


--
-- Name: downtime_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.downtime_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: downtime_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.downtime_logs_id_seq OWNED BY public.downtime_logs.id;


--
-- Name: downtime_reasons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.downtime_reasons (
    id integer NOT NULL,
    reason_name character varying(100) NOT NULL
);


--
-- Name: downtime_reasons_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.downtime_reasons_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: downtime_reasons_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.downtime_reasons_id_seq OWNED BY public.downtime_reasons.id;


--
-- Name: floor_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.floor_messages (
    id integer NOT NULL,
    "timestamp" timestamp without time zone,
    operator_name character varying(100) NOT NULL,
    sender_name character varying(100) NOT NULL,
    message text NOT NULL,
    is_manager_reply integer,
    operator_id integer,
    sender_id integer
);


--
-- Name: floor_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.floor_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: floor_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.floor_messages_id_seq OWNED BY public.floor_messages.id;


--
-- Name: lot_verifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lot_verifications (
    id integer NOT NULL,
    "timestamp" timestamp without time zone,
    date date,
    operator_name character varying(100) NOT NULL,
    operator_id integer,
    pump_station character varying(50) NOT NULL,
    pump_station_id integer,
    shift character varying(20) DEFAULT 'Shift 1'::character varying,
    cartridge_type character varying(20) DEFAULT 'V2'::character varying,
    resin_type character varying(100),
    resin_spec_id integer,
    expected_lot character varying(50),
    entered_lot character varying(50),
    entered_expiry character varying(20),
    expiry_status character varying(20),
    result character varying(20) NOT NULL,
    check_level character varying(20) DEFAULT 'full'::character varying,
    reason text,
    photo_filename character varying(255),
    ocr_lot character varying(50),
    ocr_conflict integer DEFAULT 0,
    production_log_id integer
);


--
-- Name: lot_verifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.lot_verifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: lot_verifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.lot_verifications_id_seq OWNED BY public.lot_verifications.id;


--
-- Name: plant_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plant_settings (
    id integer NOT NULL,
    target_lph double precision,
    shift_1_start character varying(10),
    shift_1_hours double precision,
    shift_2_start character varying(10),
    shift_2_hours double precision,
    yield_target_pct double precision,
    packing_target_uph double precision DEFAULT 500.0,
    shift_3_start character varying(10) DEFAULT '23:00'::character varying,
    shift_3_hours double precision DEFAULT 7.0,
    packing_yield_target_pct double precision DEFAULT 99.5,
    shift_1_break_mins double precision DEFAULT 60.0,
    shift_2_break_mins double precision DEFAULT 60.0,
    shift_3_break_mins double precision DEFAULT 60.0,
    enable_packing integer DEFAULT 1,
    shift_count integer DEFAULT 2,
    pump_form_url text,
    pump_form_label character varying(60),
    simple_mode integer DEFAULT 1 NOT NULL,
    enable_bulk_pour integer,
    operating_days character varying(7)
);


--
-- Name: plant_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.plant_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: plant_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.plant_settings_id_seq OWNED BY public.plant_settings.id;


--
-- Name: production_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.production_logs (
    id integer NOT NULL,
    "timestamp" timestamp without time zone,
    date date,
    log_type character varying(50) NOT NULL,
    operator_name character varying(100) NOT NULL,
    pump_station character varying(50) NOT NULL,
    shift character varying(20),
    cartridge_type character varying(20),
    resin_type character varying(100),
    lot_number character varying(50),
    bottles_filled integer,
    scrap_empty integer,
    scrap_filled integer,
    notes text,
    operator_id integer,
    pump_station_id integer,
    resin_spec_id integer,
    verify_status character varying(20),
    check_weight_g double precision,
    weight_deviation_g double precision,
    weight_status character varying(10),
    litres_poured double precision,
    pour_note character varying(120)
);


--
-- Name: production_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.production_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: production_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.production_logs_id_seq OWNED BY public.production_logs.id;


--
-- Name: pump_stations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pump_stations (
    id integer NOT NULL,
    station_name character varying(100) NOT NULL,
    status character varying(20),
    notes character varying(255)
);


--
-- Name: pump_stations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.pump_stations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pump_stations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.pump_stations_id_seq OWNED BY public.pump_stations.id;


--
-- Name: reactors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reactors (
    id integer NOT NULL,
    reactor_name character varying(100) NOT NULL,
    max_capacity_l integer,
    status character varying(20),
    current_resin character varying(100),
    assigned_pump character varying(50),
    current_resin_id integer,
    assigned_pump_id integer,
    vessel_type character varying(20),
    asset_tag character varying(30),
    bay_marker character varying(10)
);


--
-- Name: reactors_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reactors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reactors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.reactors_id_seq OWNED BY public.reactors.id;


--
-- Name: resin_specs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resin_specs (
    id integer NOT NULL,
    cartridge_type character varying(20) NOT NULL,
    sku character varying(100),
    resin_code character varying(50),
    lifetime_months character varying(20),
    resin_name character varying(100) NOT NULL,
    actual_spec_g double precision NOT NULL,
    min_weight_g double precision NOT NULL,
    max_weight_g double precision NOT NULL,
    acceptable_range character varying(50),
    multiplier double precision,
    color_tag character varying(20),
    units_per_skid integer DEFAULT 500
);


--
-- Name: resin_specs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.resin_specs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: resin_specs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.resin_specs_id_seq OWNED BY public.resin_specs.id;


--
-- Name: sheet_targets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sheet_targets (
    id integer NOT NULL,
    name character varying(80) NOT NULL,
    webhook_url text NOT NULL,
    owner_user_id integer,
    owner_name character varying(100),
    is_shared integer DEFAULT 0,
    created_at timestamp without time zone,
    last_sync_at timestamp without time zone,
    last_status character varying(200),
    last_rows integer
);


--
-- Name: sheet_targets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sheet_targets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sheet_targets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sheet_targets_id_seq OWNED BY public.sheet_targets.id;


--
-- Name: suggestions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.suggestions (
    id integer NOT NULL,
    "timestamp" timestamp without time zone,
    user_name character varying(100) NOT NULL,
    user_role character varying(20) NOT NULL,
    category character varying(50),
    suggestion text NOT NULL,
    status character varying(20),
    admin_notes text
);


--
-- Name: suggestions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.suggestions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: suggestions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.suggestions_id_seq OWNED BY public.suggestions.id;


--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_sessions (
    id integer NOT NULL,
    token character varying(64) NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp without time zone,
    expires_at timestamp without time zone NOT NULL
);


--
-- Name: user_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_sessions_id_seq OWNED BY public.user_sessions.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    pin character varying(255) NOT NULL,
    full_name character varying(100) NOT NULL,
    role character varying(20) NOT NULL,
    target_lph double precision DEFAULT 400.0,
    shift character varying(20) DEFAULT 'Shift 1'::character varying,
    email character varying(120),
    preferred_theme character varying(50) DEFAULT 'Default Dark'::character varying,
    avatar_filename character varying(255),
    failed_login_attempts integer DEFAULT 0,
    locked_until timestamp without time zone
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: assigned_runs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assigned_runs ALTER COLUMN id SET DEFAULT nextval('public.assigned_runs_id_seq'::regclass);


--
-- Name: cleanliness_audits id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cleanliness_audits ALTER COLUMN id SET DEFAULT nextval('public.cleanliness_audits_id_seq'::regclass);


--
-- Name: daily_checklists id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_checklists ALTER COLUMN id SET DEFAULT nextval('public.daily_checklists_id_seq'::regclass);


--
-- Name: device_readings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_readings ALTER COLUMN id SET DEFAULT nextval('public.device_readings_id_seq'::regclass);


--
-- Name: device_tag_maps id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_tag_maps ALTER COLUMN id SET DEFAULT nextval('public.device_tag_maps_id_seq'::regclass);


--
-- Name: devices id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.devices ALTER COLUMN id SET DEFAULT nextval('public.devices_id_seq'::regclass);


--
-- Name: downtime_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.downtime_logs ALTER COLUMN id SET DEFAULT nextval('public.downtime_logs_id_seq'::regclass);


--
-- Name: downtime_reasons id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.downtime_reasons ALTER COLUMN id SET DEFAULT nextval('public.downtime_reasons_id_seq'::regclass);


--
-- Name: floor_messages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.floor_messages ALTER COLUMN id SET DEFAULT nextval('public.floor_messages_id_seq'::regclass);


--
-- Name: lot_verifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lot_verifications ALTER COLUMN id SET DEFAULT nextval('public.lot_verifications_id_seq'::regclass);


--
-- Name: plant_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plant_settings ALTER COLUMN id SET DEFAULT nextval('public.plant_settings_id_seq'::regclass);


--
-- Name: production_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_logs ALTER COLUMN id SET DEFAULT nextval('public.production_logs_id_seq'::regclass);


--
-- Name: pump_stations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pump_stations ALTER COLUMN id SET DEFAULT nextval('public.pump_stations_id_seq'::regclass);


--
-- Name: reactors id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reactors ALTER COLUMN id SET DEFAULT nextval('public.reactors_id_seq'::regclass);


--
-- Name: resin_specs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resin_specs ALTER COLUMN id SET DEFAULT nextval('public.resin_specs_id_seq'::regclass);


--
-- Name: sheet_targets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sheet_targets ALTER COLUMN id SET DEFAULT nextval('public.sheet_targets_id_seq'::regclass);


--
-- Name: suggestions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suggestions ALTER COLUMN id SET DEFAULT nextval('public.suggestions_id_seq'::regclass);


--
-- Name: user_sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions ALTER COLUMN id SET DEFAULT nextval('public.user_sessions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
0014_operating_days
\.


--
-- Data for Name: assigned_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.assigned_runs (id, created_at, reactor_id, reactor_size_l, resin_type, cartridge_type, target_units, current_units, assigned_operator, pump_station, status, lot_number, notes, run_type, resin_spec_id, operator_id, pump_station_id) FROM stdin;
\.


--
-- Data for Name: cleanliness_audits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cleanliness_audits (id, "timestamp", date, audit_type, operator_name, pump_station, shift, resin_type, image_filename, is_spill, notes, operator_id, pump_station_id, resin_spec_id) FROM stdin;
13	2026-08-29 15:47:29.667064	2026-08-29	Start Of Shift (Cleanliness Check)	operator	New Pump #1	Shift 1	\N	audit_20260829_154729_314649.png	No	test	22	1	\N
14	2026-08-29 16:01:11.108382	2026-08-29	Start Of Shift (Cleanliness Check)	operator	New Pump #1	Shift 1	\N	audit_20260829_160111_bb4873.png	No	test	22	1	\N
15	2026-08-30 14:40:08.572197	2026-08-30	Start Of Shift (Cleanliness Check)	operator	New Pump #1	Shift 1	\N	audit_20260830_144008_1a5531.png	No		22	1	\N
16	2026-08-30 14:53:28.692836	2026-08-30	Start Of Shift (Cleanliness Check)	admin	New Pump #1	Shift 2	\N	audit_20260830_145328_b1cd84.png	No		26	1	\N
17	2026-09-04 10:08:22.625515	2026-09-04	Start Of Shift (Cleanliness Check)	Keagan Cooper-Lawson	New Pump #1	Shift 1	\N	audit_20260904_100822_7277e0.jpg	No	Clean	28	1	\N
18	2026-09-04 17:05:17.649622	2026-09-04	Station / Pump Transfer Check	Keagan Cooper-Lawson	New Pump #1	Shift 1	\N	audit_20260904_170517_8ac140.jpg	No	Moving to flex80a	28	1	\N
\.


--
-- Data for Name: daily_checklists; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.daily_checklists (id, date, operator_name, shift, "timestamp", operator_id, pump_station, pump_station_id) FROM stdin;
2	2026-08-25	Keagan C.	Shift 1	2026-08-25 21:32:50.725047	\N	\N	\N
4	2026-08-29	operator	Shift 1	2026-08-29 16:01:30.533124	22	\N	\N
5	2026-08-30	operator	Shift 1	2026-08-30 14:40:12.065452	22	\N	\N
6	2026-08-30	admin	Shift 2	2026-08-30 14:53:30.949742	26	\N	\N
7	2026-08-30	admin	Shift 1	2026-08-30 14:53:44.019474	26	\N	\N
1	2026-08-25	Keagan Cooper-Lawson	Shift 1	2026-08-25 21:28:50.713493	28	\N	\N
3	2026-08-26	Keagan Cooper-Lawson	Shift 1	2026-08-26 10:11:11.093534	28	\N	\N
8	2026-09-04	Keagan Cooper-Lawson	Shift 1	2026-09-04 10:08:24.566626	28	New Pump #1	1
\.


--
-- Data for Name: device_readings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.device_readings (id, device_id, "timestamp", metric, value_numeric, value_text) FROM stdin;
\.


--
-- Data for Name: device_tag_maps; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.device_tag_maps (id, device_id, raw_tag, canonical_metric, data_type, scale_factor, unit) FROM stdin;
\.


--
-- Data for Name: devices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.devices (id, device_name, device_role, protocol, connection_json, poll_interval_s, is_enabled, pump_station_id, reactor_id, status, last_seen_at, last_error, notes, created_at) FROM stdin;
\.


--
-- Data for Name: downtime_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.downtime_logs (id, "timestamp", date, operator_name, pump_station, shift, reason, duration_min, notes, operator_id, pump_station_id) FROM stdin;
\.


--
-- Data for Name: downtime_reasons; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.downtime_reasons (id, reason_name) FROM stdin;
1	Break/Shift Change
2	Carts/Bins
3	Change-Over
4	Machine Maintenance / Pump Jam
5	Resin Spill
6	Scale Calibration / Tare
7	Waiting on Bulk Resin Tote
\.


--
-- Data for Name: floor_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.floor_messages (id, "timestamp", operator_name, sender_name, message, is_manager_reply, operator_id, sender_id) FROM stdin;
3	2026-08-29 16:58:42.054583	operator	operator	test	0	22	22
4	2026-08-29 16:59:37.917246	operator	Plant Lead	test	1	22	\N
1	2026-08-25 21:37:15.186452	Keagan Cooper-Lawson	Keagan Cooper-Lawson	Hello, test test!	0	28	28
2	2026-08-25 21:37:46.097398	Keagan Cooper-Lawson	Plant Lead	Test Test!	1	28	\N
5	2026-09-07 12:24:15.000546	manager	manager	Test	0	24	24
\.


--
-- Data for Name: lot_verifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lot_verifications (id, "timestamp", date, operator_name, operator_id, pump_station, pump_station_id, shift, cartridge_type, resin_type, resin_spec_id, expected_lot, entered_lot, entered_expiry, expiry_status, result, check_level, reason, photo_filename, ocr_lot, ocr_conflict, production_log_id) FROM stdin;
1	2026-09-04 11:31:54.615446	2026-09-04	Keagan Cooper-Lawson	28	New Pump #1	1	Shift 1	V2	Alpha Clear V1	49	\N	20260824	\N	\N	recorded	record	\N	\N	\N	0	70
2	2026-09-04 12:29:57.644021	2026-09-04	Keagan Cooper-Lawson	28	New Pump #1	1	Shift 1	V2	Alpha Clear V1	49	\N	20260824	\N	\N	recorded	record	\N	\N	\N	0	71
3	2026-09-04 13:45:17.711506	2026-09-04	Keagan Cooper-Lawson	28	New Pump #1	1	Shift 1	V2	Alpha Clear V1	49	\N	20260824	\N	\N	recorded	record	\N	\N	\N	0	72
4	2026-09-04 14:30:38.652242	2026-09-04	Keagan Cooper-Lawson	28	New Pump #1	1	Shift 1	V2	Alpha Clear V1	49	\N	20260824	\N	\N	recorded	record	\N	\N	\N	0	73
5	2026-09-04 15:28:42.50887	2026-09-04	Keagan Cooper-Lawson	28	New Pump #1	1	Shift 1	V2	Alpha Clear V1	49	\N	20260824	\N	\N	recorded	record	\N	\N	\N	0	74
6	2026-09-04 17:02:36.658112	2026-09-04	Keagan Cooper-Lawson	28	New Pump #1	1	Shift 1	V2	Alpha Clear V1	49	\N	20260824	\N	\N	recorded	record	\N	\N	\N	0	75
\.


--
-- Data for Name: plant_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.plant_settings (id, target_lph, shift_1_start, shift_1_hours, shift_2_start, shift_2_hours, yield_target_pct, packing_target_uph, shift_3_start, shift_3_hours, packing_yield_target_pct, shift_1_break_mins, shift_2_break_mins, shift_3_break_mins, enable_packing, shift_count, pump_form_url, pump_form_label, simple_mode, enable_bulk_pour, operating_days) FROM stdin;
1	400	06:00	8.5	14:00	8.5	99	500	23:00	7	99.5	60	60	60	0	2	https://docs.google.com/forms/d/e/1FAIpQLSd9b9fFPU5-p93ncCqPw7UFLNbzUH_hJTAxXKdIjOCq7bEVdA/viewform		1	1	1111100
\.


--
-- Data for Name: production_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.production_logs (id, "timestamp", date, log_type, operator_name, pump_station, shift, cartridge_type, resin_type, lot_number, bottles_filled, scrap_empty, scrap_filled, notes, operator_id, pump_station_id, resin_spec_id, verify_status, check_weight_g, weight_deviation_g, weight_status, litres_poured, pour_note) FROM stdin;
70	2026-09-04 11:31:54.604935	2026-09-04	Hourly Bottle Count	Keagan Cooper-Lawson	New Pump #1	Shift 1	V2	Alpha Clear V1	20260824	650	0	0		28	1	49	recorded	1109	-1	in	\N	\N
71	2026-09-04 12:29:57.642517	2026-09-04	Hourly Bottle Count	Keagan Cooper-Lawson	New Pump #1	Shift 1	V2	Alpha Clear V1	20260824	392	0	0		28	1	49	recorded	\N	\N	\N	\N	\N
72	2026-09-04 13:45:17.710507	2026-09-04	Hourly Bottle Count	Keagan Cooper-Lawson	New Pump #1	Shift 1	V2	Alpha Clear V1	20260824	537	0	0		28	1	49	recorded	1110	0	in	\N	\N
73	2026-09-04 14:30:38.650737	2026-09-04	Hourly Bottle Count	Keagan Cooper-Lawson	New Pump #1	Shift 1	V2	Alpha Clear V1	20260824	319	0	0		28	1	49	recorded	1110.5	0.5	in	\N	\N
74	2026-09-04 15:28:42.50787	2026-09-04	Hourly Bottle Count	Keagan Cooper-Lawson	New Pump #1	Shift 1	V2	Alpha Clear V1	20260824	445	0	0		28	1	49	recorded	1110	0	in	\N	\N
75	2026-09-04 17:02:36.657109	2026-09-04	Hourly Bottle Count	Keagan Cooper-Lawson	New Pump #1	Shift 1	V2	Alpha Clear V1	20260824	336	0	0	End of V2 cartridges	28	1	49	recorded	\N	\N	\N	\N	\N
\.


--
-- Data for Name: pump_stations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pump_stations (id, station_name, status, notes) FROM stdin;
1	New Pump #1	Active	Automated Line 1
2	New Pump #2	Active	Automated Line 2
3	Old Pump/Other	Active	Manual / Backup
\.


--
-- Data for Name: reactors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reactors (id, reactor_name, max_capacity_l, status, current_resin, assigned_pump, current_resin_id, assigned_pump_id, vessel_type, asset_tag, bay_marker) FROM stdin;
31	M-304	5000	Active	\N	\N	\N	\N	cone_mixer	\N	\N
32	test	3000	Active	\N	\N	\N	\N	cone_mixer	\N	\N
33	testt	1000	Active	\N	\N	\N	\N	ibc_tote	\N	\N
\.


--
-- Data for Name: resin_specs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.resin_specs (id, cartridge_type, sku, resin_code, lifetime_months, resin_name, actual_spec_g, min_weight_g, max_weight_g, acceptable_range, multiplier, color_tag, units_per_skid) FROM stdin;
1	V1	RS-F2-GPBK-04	FLGPBK04	24	Black V4	1090	1080	1095	1080-1095	1	#1E3A8A	500
2	V1	RS-F2-GPCL-04	FLGPCL04	24	Clear V4	1090	1080	1095	1080-1095	1	#1E3A8A	500
3	V1	RS-F2-DMBE-02	FLDMBE02	18	Model V2	1090	1080	1095	1080-1095	1	#1E3A8A	500
4	V1	RS-F2-DUCL-02	FLDUCL02	24	Durable V2	1070	1060	1075	1060-1075	1	#1E3A8A	500
5	V1	RS-F2-DRGR-02	FLDRGR02	24	Draft V2	1120	1110	1125	1110-1125	1	#1E3A8A	500
6	V1	RS-F2-FL80-01	FLFL8001	24	Flexible 80A V1	1070	1060	1075	1060-1075	1	#1E3A8A	500
7	V1	RS-F2-PRGR-01	FLPRGR01	24	Grey Pro V1	1080	1070	1085	1070-1085	1	#1E3A8A	500
8	V1	RS-F2-GPGR-04	FLGPGR04	24	Grey V4	1080	1070	1085	1070-1085	1	#1E3A8A	500
9	V1	RS-F2-RG10-01	FLRG1001	24	Rigid 10K V1	1630	1620	1635	1620-1635	1	#1E3A8A	500
10	V1	RS-F2-TO15-01	FLTO1501	24	Tough 1500 V1	1070	1060	1075	1060-1075	1	#1E3A8A	500
11	V1	RS-F2-GPWH-04	FLGPWH04	24	White V4	1080	1070	1085	1070-1085	1	#1E3A8A	500
12	V1	RS-F2-DMBE-03	FLDMBE03	24	Model V3	1120	1110	1125	1110-1125	1	#1E3A8A	500
13	V1	RS-F2-TO20-01	FLTO2001	24	Tough 2000 V1	1110	1100	1115	1100-1115	1	#1E3A8A	500
14	V1	RS-F2-GPGR-41	FLGPGR41	24	Grey V4.1	1110	1100	1115	1100-1115	1	#1E3A8A	500
15	V1	RS-F2-GPCL-41	FLGPCL41	24	Clear V4.1	1110	1100	1115	1100-1115	1	#1E3A8A	500
16	V1	RS-F2-GPWH-41	FLGPWH41	24	White V4.1	1110	1100	1115	1100-1115	1	#1E3A8A	500
17	V1	RS-F2-GPBK-41	FLGPBK41	24	Black V4.1	1110	1100	1115	1100-1115	1	#1E3A8A	500
18	V1	RS-F2-FLCB-01	FLFL8001	24	Flexible 80A WCK	1070	1060	1075	1060-1075	1	#1E3A8A	500
19	V1/V2	RS-F2-RGWH-01	FLRGWH01	24	Rigid 4000 V1	1260	1250	1265	1250-1265	1	#0D9488	500
20	V1/V2	RS-F2-GPCB-01	FLGPCB01	24	Color Base V1	864	859	869	859-869	1	#0D9488	500
21	V1/V2	RS-F2-HTAM-02	FLHTAM02	24	High Temp V2	1140	1130	1145	1130-1145	1	#0D9488	500
22	V1/V2	RS-F2-CWPU-01	FLCWPU01	24	Castable Wax V1	1110	1100	1115	1100-1115	1	#0D9488	500
23	V1/V2	RS-F2-CW40-01	FLCW4001	24	Castable Wax 40 V1	1010	1000	1015	1000-1015	1	#0D9488	500
24	V1/V2	RS-F2-FRGR-01	FLFRGR01	18	Flame Retardant V1	1000	990	1005	990-1005	1	#0D9488	500
25	V1/V2	RS-F2-ESDS-01	FLESDS01	24	ESD V1	1060	1050	1065	1050-1065	1	#0D9488	500
26	V1/V2	RS-F2-SI40-01	FLSI4001	24	Silicone 40A V1	1020	1010	1025	1010-1025	1	#0D9488	500
27	V1/V2	RS-F2-ELCL-02	FLELCL02	24	Elastic 50A V2	1010	1000	1015	1000-1015	1	#0D9488	500
28	V1/V2	RS-F2-AL4N-01	FLAL4N01	12	Alumina 4N V1	2000	1990	2005	1990-2005	1	#0D9488	500
29	V1/V2	RS-F2-CCCL-01	FLCCCL01	24	Clear Cast V1	1090	1080	1095	1080-1095	1	#0D9488	500
48	V2	RS-C2-APBK-01	FLAPBK01	24	Alpha Black V1	1110	1100	1115	1100-1115	1	#7C2D12	500
49	V2	RS-C2-APCL-01	FLAPCL01	24	Alpha Clear V1	1110	1100	1115	1100-1115	1	#7C2D12	500
50	V2	RS-C2-APFA-01	FLAPFA01	24	Alpha Fast V1	1110	1100	1115	1100-1115	1	#7C2D12	500
51	V2	RS-C2-APGR-01	FLAPGR01	24	Alpha Grey V1	1110	1100	1115	1100-1115	1	#7C2D12	500
52	V2	RS-C2-APMD-01	FLAPMD01	24	Alpha Model V1	1110	1100	1115	1100-1115	1	#7C2D12	500
53	V2	RS-C2-APWH-01	FLAPWH01	24	Alpha White V1	1110	1100	1115	1100-1115	1	#7C2D12	500
56	RPS	RS-RPS-GPCL-04	FLGPCL04	24	Clear V4	5450	5400	5475	5400-5475	5	#16A34A	500
57	RPS	RS-RPS-DRGR-02	FLDRGR02	24	Draft V2	5600	5550	5625	5550-5625	5	#16A34A	500
58	RPS	RS-RPS-GPGR-04	FLGPGR04	24	Grey V4	5400	5350	5425	5350-5425	5	#16A34A	500
59	RPS	RS-RPS-DMBE-03	FLDMBE03	24	Model V3	5600	5550	5625	5550-5625	5	#16A34A	500
60	RPS	RS-RPS-TO20-01	FLTO2001	24	Tough 2000 V1	5550	5500	5575	5500-5575	5	#16A34A	500
61	RPS	RS-RPS-HTAM-02	FLHTAM02	24	High Temp V2	5700	5650	5725	5650-5725	5	#16A34A	500
62	RPS	RS-RPS-DUCL-02	FLDUCL02	24	Durable V2	5350	5300	5375	5300-5375	5	#16A34A	500
63	RPS	RS-RPS-RGWH-01	FLRGWH01	24	Rigid 4K V1	6300	6250	6325	6250-6325	5	#16A34A	500
64	RPS	RS-RPS-GPBK-04	FLGPBK04	24	Black V4	5450	5400	5475	5400-5475	5	#16A34A	500
65	RPS	RS-RPS-DMBE-02	FLDMBE02	18	Model V2	5450	5400	5475	5400-5475	5	#16A34A	500
66	RPS	RS-RPS-GPWH-04	FLGPWH04	24	White V4	5400	5350	5425	5350-5425	5	#16A34A	500
67	RPS	RS-RPS-FL80-01	FLFL8001	24	Flexible 80A V1	5350	5300	5375	5300-5375	5	#16A34A	500
68	RPS	RS-RPS-PRGR-01	FLPRGR01	24	Grey Pro V1	5400	5350	5425	5350-5425	5	#16A34A	500
69	RPS	RS-RPS-ESDS-01	FLESDS01	24	ESD V1	5300	5250	5325	5250-5325	5	#16A34A	500
70	RPS	RS-RPS-TO15-01	FLTO1501	24	Tough 1500 V1	5350	5300	5375	5300-5375	5	#16A34A	500
71	RPS	RS-RPS-GPCL-05	FLGPCL05	24	Clear V5	5550	5500	5575	5500-5575	5	#16A34A	500
72	RPS	RS-RPS-GPGR-05	FLGPGR05	24	Grey V5	5550	5500	5575	5500-5575	5	#16A34A	500
73	RPS	RS-RPS-GPWH-05	FLGPWH05	24	White V5	5600	5550	5625	5550-5625	5	#16A34A	500
74	RPS	RS-RPS-GPBK-05	FLGPBK05	24	Black V5	5550	5500	5575	5500-5575	5	#16A34A	500
75	RPS	RS-RPS-FMGR-01	FLFMGR01	24	Fast Model V1	5600	5550	5625	5550-5625	5	#16A34A	500
76	RPS	RS-RPS-PMBE-01	FLPMBE01	24	Precision Model V1	5600	5550	5625	5550-5625	5	#16A34A	500
77	RPS	RS-RPS-TO20-11	FLTO2011	24	Tough 2000 V1.1	5550	5500	5575	5500-5575	5	#16A34A	500
78	RPS	RS-RPS-CWPU-01	FLCWPU01	24	Castable Wax V1	5550	5500	5575	5500-5575	5	#16A34A	500
79	RPS	RS-RPS-SI40-01	FLSI4001	24	Silicone 40A V1	5100	5050	5125	5050-5125	5	#16A34A	500
80	RPS	RS-RPS-GPCL-41	FLGPCL41	24	Clear V4.1	5550	5500	5575	5500-5575	5	#16A34A	500
81	RPS	RS-RPS-TO15-11	FLTO1511	24	Tough 1500 V1.1	5350	5300	5375	5300-5375	5	#16A34A	500
82	RPS	RS-RPS-CCCL-01	FLCCCL01	24	Clear Cast V1	5450	5400	5475	5400-5475	5	#16A34A	500
83	RPS	RS-RPS-GPGR-41	FLGPGR41	24	Grey V4.1	5550	5500	5575	5500-5575	5	#16A34A	500
84	RPS	RS-RPS-TO15-02	FLTO1502	24	Tough 1500 V2	5100	5050	5125	5050-5125	5	#16A34A	500
85	RPS	RS-RPS-GPWH-41	FLGPWH41	24	White V4.1	5550	5500	5575	5500-5575	5	#16A34A	500
86	RPS	RS-RPS-GPBK-41	FLGPBK41	24	Black V4.1	5550	5500	5575	5500-5575	5	#16A34A	500
87	RPS	RS-RPS-DUCL-21	FLDUCL21	24	Durable V2.1	5350	5300	5375	5300-5375	5	#16A34A	500
88	RPS	RS-RPS-FL80-11	FLFL8011	24	Flexible 80A V1.1	5350	5300	5375	5300-5375	5	#16A34A	500
89	RPS	RS-RPS-FMBF-01	FLFMGR01	24	Fast Model BF V1	5600	5500	5625	5500-5625	5	#16A34A	500
90	RPS	RS-RPS-GING-01	-	24	Gingiva Resin	4280	4240	4300	4240-4300	5	#16A34A	500
91	RPS	RS-RPS-ELCL-02	FLELCL02	24	Elastic 50A V2	5050	5000	5075	5000-5075	5	#16A34A	500
92	RPS	RS-RPS-TO20-02	FLTO2002	24	Tough 2000 V2	5150	5100	5175	5100-5175	5	#16A34A	500
93	RPS	RS-RPS-TO10-01	FLTO1001	24	Tough 1000 V1	5050	5000	5075	5000-5075	5	#16A34A	500
94	RPS	RS-RPS-FL80-02	FLFL8002	24	Flexible 80A V2	5200	5150	5225	5150-5225	5	#16A34A	500
95	RPS	RS-RPS-TO20-TC	TCTO2002	24	Tough (TO20-TC)	5155	5105	5180	5105-5180	5	#16A34A	500
96	Pigment	RS-F2-CRCY-01	-	24	Cyan Pigment	124	123	128	123-128	1	#E11D48	500
97	Pigment	RS-F2-CRYL-01	-	24	Yellow Pigment	124	123	128	123-128	1	#E11D48	500
98	Pigment	RS-F2-CRMA-01	-	24	Magenta Pigment	124	123	128	123-128	1	#E11D48	500
99	Pigment	RS-F2-CRBK-01	-	24	Black Pigment	124	123	128	123-128	1	#E11D48	500
100	Pigment	RS-F2-CRWH-01	-	24	White Pigment	124	123	128	123-128	1	#E11D48	500
101	Pigment	FS1-FB-PMA-01	-	24	Polishing Agent	135	131	139	131-139	1	#E11D48	500
102	Amazon	RS-B1-CRCL-01	CRCL-01	24	Creator Super Clear	1000	990	1005	990-1005	1	#CA8A04	500
103	Amazon	RS-B1-CRTO-01	CRTO-01	24	Creator Tough	1000	990	1005	990-1005	1	#CA8A04	500
104	Amazon	RS-B1-TCLV-01	FLTCLV01	24	True Cast V1	500	490	505	490-505	1	#CA8A04	500
30	V2	RS-C2-GPCL-05	FLGPCL05	24	Clear V5	1110	1100	1115	1100-1115	1	#EBF5FA	500
31	V2	RS-C2-GPGR-05	FLGPGR05	24	Grey V5	1110	1100	1115	1100-1115	1	#666B6D	500
32	V2	RS-C2-GPWH-05	FLGPWH05	24	White V5	1120	1110	1125	1110-1125	1	#E9E8CC	500
33	V2	RS-C2-GPBK-05	FLGPBK05	24	Black V5	1110	1100	1115	1100-1115	1	#3B3C3C	500
34	V2	RS-C2-FMGR-01	FLFMGR01	24	Fast Model V1	1120	1110	1125	1110-1125	1	#818277	500
35	V2	RS-C2-PMBE-01	FLPMBE01	24	Precision Model V1	1120	1110	1125	1110-1125	1	#F5CBA6	500
36	V2	RS-C2-DUCL-21	FLDUCL21	24	Durable V2.1	1070	1060	1075	1060-1075	1	#F6DB6F	500
37	V2	RS-C2-RG10-11	FLRG1011	24	Rigid 10K V1.1	1630	1620	1635	1620-1635	1	#F1F5FE	500
38	V2	RS-C2-TO15-11	FLTO1511	24	Tough 1500 V1.1	1070	1060	1075	1060-1075	1	#424548	500
39	V2	RS-C2-FL80-11	FLFL8011	24	Flexible 80A V1.1	1070	1060	1075	1060-1075	1	#1ABC9C	500
40	V2	RS-C2-TO20-11	FLTO2011	24	Tough 2000 V1.1	1110	1100	1115	1100-1115	1	#53585B	500
41	V2	RS-C2-TO15-02	FLTO1502	24	Tough 1500 V2	1020	1010	1025	1010-1025	1	#424548	500
42	V2	RS-C2-TCLV-01	FLTCLV01	24	True Cast V1	1070	1060	1075	1060-1075	1	#907DCA	500
43	V2	RS-C2-GPCO-05	FLGPCO05	24	Color V5	1069	1064	1074	1064-1074	1	#CCB4E4	500
44	V2	RS-C2-BDFERE-01	BDFERE01	24	Resist	975	965	980	965-980	1	#A3CA7D	500
45	V2	RS-C2-TO20-02	FLTO2002	24	Tough 2000 V2	1030	1020	1035	1020-1035	1	#53585B	500
46	V2	RS-C2-TO10-01	FLTO1001	24	Tough 1000 V1	1010	1000	1015	1000-1015	1	#424548	500
47	V2	RS-C2-FL80-02	FLFL8002	24	Flexible 80A V2	1040	1030	1045	1030-1045	1	#1ABC9C	500
54	V2	RS-C2-ST15-02	FLST1502	24	Tough 1500 V2 - Clerk	1020	1010	1025	1010-1025	1	#424548	500
55	V2	RS-C2-FL50-01	FLFL5001	24	Flexible 50A V1	1010	1000	1015	1000-1015	1	#1ABC9C	500
105	V1	RS-F2-GPCL-41	FLGPCL41	24	Clear V4.1	1110	1100	1115	1100-1115	1	#EBF5FA	500
\.


--
-- Data for Name: sheet_targets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sheet_targets (id, name, webhook_url, owner_user_id, owner_name, is_shared, created_at, last_sync_at, last_status, last_rows) FROM stdin;
2	Test	https://script.google.com/macros/s/AKfycbwpILKbht7dOS-NXZbAMAPrpjMXfJf6vispOCAe5C9zgem3eQZbXnH3LVo_kDFkQSmy/exec	26	admin	0	2026-09-07 03:19:41.95377	2026-09-07 03:22:56.779294	ok	1
3	test	https://script.google.com/macros/s/AKfycbwpILKbht7dOS-NXZbAMAPrpjMXfJf6vispOCAe5C9zgem3eQZbXnH3LVo_kDFkQSmy/exec	24	manager	0	2026-09-07 12:15:04.782888	2026-09-07 12:15:29.924378	ok	1
\.


--
-- Data for Name: suggestions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.suggestions (id, "timestamp", user_name, user_role, category, suggestion, status, admin_notes) FROM stdin;
2	2026-09-04 09:21:02.067005	Keagan Cooper-Lawson	operator	App Bug / Error	Navigation on phone is bring weird	Implemented	\N
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_sessions (id, token, user_id, created_at, expires_at) FROM stdin;
1	-eyjbdb5pnbheE_sTRTHH36EU0ktYgH_1ljvCt5E1wY	21	2026-08-29 21:14:44.110436	2026-09-28 21:14:44.109435
2	Pw2ker78MIpKJPSPVrhSvrRlkAHvAEyN0Rbj37D38MQ	21	2026-08-29 21:15:00.503432	2026-09-28 21:15:00.503165
3	ii95N0ulPfVlJd5SMuGndjkxQzm-jo_1fK2x-Q5rjn8	21	2026-08-29 21:31:41.995285	2026-09-28 21:31:41.994359
4	_eOqULTXyE2b84Bn6v0kq7v7fwrAq6yLaVnDCVyIBKY	21	2026-08-29 23:01:36.539122	2026-09-28 23:01:36.538426
5	w7l5VJ1zX3g4jkLqXzKR2UGsVj8vcurVtMpN4yTteI8	21	2026-08-29 23:29:40.623889	2026-09-28 23:29:40.623416
6	sHPSQBm57OpUy2e-OAc3K_5vaKZT1zF166bo-s6VWwY	22	2026-08-30 02:42:29.489877	2026-09-29 02:42:29.489029
7	peVYXrVlYpwY9M8siC3zUHiNalFKZk9X3GyDg3h6w6o	26	2026-08-30 17:21:31.144721	2026-09-29 17:21:31.144185
8	0Q38sv1SPBqJnmxdntJeto_9niyz6Abanlz1ql3dn8o	28	2026-08-31 00:26:17.843998	2026-09-30 00:26:17.843371
9	Ybt5N_a4ZqdLJktjZp7fHTgqLr5OI-NMdad-BX-slUQ	28	2026-09-04 09:11:51.093408	2026-10-04 09:11:51.091904
10	j6u9yW9HQ0loZFXwxJkv2tl3fvSjL4idCu14P6qld84	28	2026-09-04 10:02:53.600992	2026-10-04 10:02:53.600992
11	DrdAPUflpbEgM3iuCRC1OkW0pD-6sRPgndQ30pKBUZk	28	2026-09-04 10:04:35.974967	2026-10-04 10:04:35.973463
12	iF0iZ9CErCpDKpeS-j5zf8uQWI7kVF9wK4BM51YSm2w	28	2026-09-04 12:00:47.323482	2026-10-04 12:00:47.323482
13	pCNbGBvWDQmQDyMBa1olfTh4yRcl1ZQZPVzTNzZQ8Go	24	2026-09-04 14:43:10.369128	2026-10-04 14:43:10.369128
15	bK9VWfnUsah6s0m7f4LiVtWj-zM0GAz2e1Ky1iw87nU	26	2026-09-07 15:03:34.067045	2026-10-07 15:03:34.06604
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, pin, full_name, role, target_lph, shift, email, preferred_theme, avatar_filename, failed_login_attempts, locked_until) FROM stdin;
24	manager	$2b$12$0QWah/ET2fPalZ./8hlLXeOOTdK2QnnEmMn4mEekBofB65obyEHIq	manager	manager	400	Shift 1	manager@manager.com	Vaporwave 1984	\N	0	\N
28	tmpikes	$2b$12$Sb4.Ez.PfFRP9v3R54uhBuVD1cMmdNFefS4sE5RAEekqJGrH/4iQ.	Keagan Cooper-Lawson	operator	400	Shift 1	keagan.cooperlawson@formlabs.com	Nordic Frost	\N	0	\N
22	operator	$2b$12$Q9A2iu13MFqIpg4pQkj1deimKVQNZYArwzx4qICI8G6Vm/P3Gr11y	operator	operator	400	Shift 1	operator@operator.com	Glass Aurora	\N	0	\N
26	admin	$2b$12$CtbpAlYUIpIa4m7ETThPJeUsydgwpWwTaC5tGFagwCFJ1pNsu.5ju	admin	admin	0	Shift 1	admin@admin.com	Glass Aurora	avatar_26_05fef0.png	0	\N
23	packer	$2b$12$Tn5npf6enzvPziMuF1JNX.KRUwl7fbPMVkythxhKsojDlzyl8mkxK	packer	packer	400	Shift 1	packer@packer.com	Default Dark	\N	0	\N
27	operator1	$2b$12$63CcQBEOy6r0scaBcEjMpOI.9lg/cCxRPZ5pdkeCa39SnwcmYM..W	operator1	operator	400	Shift 2	operator1@operator.com	Default Dark	\N	0	\N
\.


--
-- Name: assigned_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.assigned_runs_id_seq', 44, true);


--
-- Name: cleanliness_audits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cleanliness_audits_id_seq', 18, true);


--
-- Name: daily_checklists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.daily_checklists_id_seq', 8, true);


--
-- Name: device_readings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.device_readings_id_seq', 1, false);


--
-- Name: device_tag_maps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.device_tag_maps_id_seq', 1, false);


--
-- Name: devices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.devices_id_seq', 1, false);


--
-- Name: downtime_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.downtime_logs_id_seq', 1, false);


--
-- Name: downtime_reasons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.downtime_reasons_id_seq', 7, true);


--
-- Name: floor_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.floor_messages_id_seq', 5, true);


--
-- Name: lot_verifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.lot_verifications_id_seq', 6, true);


--
-- Name: plant_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.plant_settings_id_seq', 1, true);


--
-- Name: production_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.production_logs_id_seq', 75, true);


--
-- Name: pump_stations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.pump_stations_id_seq', 3, true);


--
-- Name: reactors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.reactors_id_seq', 33, true);


--
-- Name: resin_specs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.resin_specs_id_seq', 105, true);


--
-- Name: sheet_targets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sheet_targets_id_seq', 3, true);


--
-- Name: suggestions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.suggestions_id_seq', 2, true);


--
-- Name: user_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_sessions_id_seq', 15, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 28, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: assigned_runs assigned_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assigned_runs
    ADD CONSTRAINT assigned_runs_pkey PRIMARY KEY (id);


--
-- Name: cleanliness_audits cleanliness_audits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cleanliness_audits
    ADD CONSTRAINT cleanliness_audits_pkey PRIMARY KEY (id);


--
-- Name: daily_checklists daily_checklists_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_checklists
    ADD CONSTRAINT daily_checklists_pkey PRIMARY KEY (id);


--
-- Name: device_readings device_readings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_readings
    ADD CONSTRAINT device_readings_pkey PRIMARY KEY (id);


--
-- Name: device_tag_maps device_tag_maps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_tag_maps
    ADD CONSTRAINT device_tag_maps_pkey PRIMARY KEY (id);


--
-- Name: devices devices_device_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_device_name_key UNIQUE (device_name);


--
-- Name: devices devices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_pkey PRIMARY KEY (id);


--
-- Name: downtime_logs downtime_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.downtime_logs
    ADD CONSTRAINT downtime_logs_pkey PRIMARY KEY (id);


--
-- Name: downtime_reasons downtime_reasons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.downtime_reasons
    ADD CONSTRAINT downtime_reasons_pkey PRIMARY KEY (id);


--
-- Name: downtime_reasons downtime_reasons_reason_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.downtime_reasons
    ADD CONSTRAINT downtime_reasons_reason_name_key UNIQUE (reason_name);


--
-- Name: floor_messages floor_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.floor_messages
    ADD CONSTRAINT floor_messages_pkey PRIMARY KEY (id);


--
-- Name: lot_verifications lot_verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lot_verifications
    ADD CONSTRAINT lot_verifications_pkey PRIMARY KEY (id);


--
-- Name: plant_settings plant_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plant_settings
    ADD CONSTRAINT plant_settings_pkey PRIMARY KEY (id);


--
-- Name: production_logs production_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_logs
    ADD CONSTRAINT production_logs_pkey PRIMARY KEY (id);


--
-- Name: pump_stations pump_stations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pump_stations
    ADD CONSTRAINT pump_stations_pkey PRIMARY KEY (id);


--
-- Name: pump_stations pump_stations_station_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pump_stations
    ADD CONSTRAINT pump_stations_station_name_key UNIQUE (station_name);


--
-- Name: reactors reactors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reactors
    ADD CONSTRAINT reactors_pkey PRIMARY KEY (id);


--
-- Name: reactors reactors_reactor_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reactors
    ADD CONSTRAINT reactors_reactor_name_key UNIQUE (reactor_name);


--
-- Name: resin_specs resin_specs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resin_specs
    ADD CONSTRAINT resin_specs_pkey PRIMARY KEY (id);


--
-- Name: sheet_targets sheet_targets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sheet_targets
    ADD CONSTRAINT sheet_targets_pkey PRIMARY KEY (id);


--
-- Name: suggestions suggestions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suggestions
    ADD CONSTRAINT suggestions_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: ix_cleanliness_audits_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_cleanliness_audits_date ON public.cleanliness_audits USING btree (date);


--
-- Name: ix_cleanliness_audits_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_cleanliness_audits_timestamp ON public.cleanliness_audits USING btree ("timestamp");


--
-- Name: ix_daily_checklists_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_daily_checklists_date ON public.daily_checklists USING btree (date);


--
-- Name: ix_daily_checklists_operator_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_daily_checklists_operator_name ON public.daily_checklists USING btree (operator_name);


--
-- Name: ix_daily_checklists_pump_station; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_daily_checklists_pump_station ON public.daily_checklists USING btree (pump_station);


--
-- Name: ix_daily_checklists_pump_station_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_daily_checklists_pump_station_id ON public.daily_checklists USING btree (pump_station_id);


--
-- Name: ix_device_readings_device_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_device_readings_device_id ON public.device_readings USING btree (device_id);


--
-- Name: ix_device_readings_metric; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_device_readings_metric ON public.device_readings USING btree (metric);


--
-- Name: ix_device_readings_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_device_readings_timestamp ON public.device_readings USING btree ("timestamp");


--
-- Name: ix_device_tag_maps_device_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_device_tag_maps_device_id ON public.device_tag_maps USING btree (device_id);


--
-- Name: ix_devices_pump_station_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_devices_pump_station_id ON public.devices USING btree (pump_station_id);


--
-- Name: ix_devices_reactor_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_devices_reactor_id ON public.devices USING btree (reactor_id);


--
-- Name: ix_downtime_logs_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_downtime_logs_date ON public.downtime_logs USING btree (date);


--
-- Name: ix_downtime_logs_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_downtime_logs_timestamp ON public.downtime_logs USING btree ("timestamp");


--
-- Name: ix_floor_messages_operator_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_floor_messages_operator_name ON public.floor_messages USING btree (operator_name);


--
-- Name: ix_floor_messages_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_floor_messages_timestamp ON public.floor_messages USING btree ("timestamp");


--
-- Name: ix_lot_verifications_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lot_verifications_date ON public.lot_verifications USING btree (date);


--
-- Name: ix_lot_verifications_operator_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lot_verifications_operator_id ON public.lot_verifications USING btree (operator_id);


--
-- Name: ix_lot_verifications_operator_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lot_verifications_operator_name ON public.lot_verifications USING btree (operator_name);


--
-- Name: ix_lot_verifications_production_log_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lot_verifications_production_log_id ON public.lot_verifications USING btree (production_log_id);


--
-- Name: ix_lot_verifications_pump_station; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lot_verifications_pump_station ON public.lot_verifications USING btree (pump_station);


--
-- Name: ix_lot_verifications_pump_station_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lot_verifications_pump_station_id ON public.lot_verifications USING btree (pump_station_id);


--
-- Name: ix_lot_verifications_resin_spec_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lot_verifications_resin_spec_id ON public.lot_verifications USING btree (resin_spec_id);


--
-- Name: ix_lot_verifications_result; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lot_verifications_result ON public.lot_verifications USING btree (result);


--
-- Name: ix_lot_verifications_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_lot_verifications_timestamp ON public.lot_verifications USING btree ("timestamp");


--
-- Name: ix_production_logs_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_production_logs_date ON public.production_logs USING btree (date);


--
-- Name: ix_production_logs_operator_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_production_logs_operator_name ON public.production_logs USING btree (operator_name);


--
-- Name: ix_production_logs_pump_station; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_production_logs_pump_station ON public.production_logs USING btree (pump_station);


--
-- Name: ix_production_logs_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_production_logs_timestamp ON public.production_logs USING btree ("timestamp");


--
-- Name: ix_production_logs_verify_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_production_logs_verify_status ON public.production_logs USING btree (verify_status);


--
-- Name: ix_production_logs_weight_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_production_logs_weight_status ON public.production_logs USING btree (weight_status);


--
-- Name: ix_suggestions_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_suggestions_timestamp ON public.suggestions USING btree ("timestamp");


--
-- Name: ix_user_sessions_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_user_sessions_token ON public.user_sessions USING btree (token);


--
-- Name: ix_user_sessions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_sessions_user_id ON public.user_sessions USING btree (user_id);


--
-- Name: assigned_runs assigned_runs_operator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assigned_runs
    ADD CONSTRAINT assigned_runs_operator_id_fkey FOREIGN KEY (operator_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: assigned_runs assigned_runs_pump_station_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assigned_runs
    ADD CONSTRAINT assigned_runs_pump_station_id_fkey FOREIGN KEY (pump_station_id) REFERENCES public.pump_stations(id) ON DELETE SET NULL;


--
-- Name: assigned_runs assigned_runs_resin_spec_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assigned_runs
    ADD CONSTRAINT assigned_runs_resin_spec_id_fkey FOREIGN KEY (resin_spec_id) REFERENCES public.resin_specs(id) ON DELETE SET NULL;


--
-- Name: cleanliness_audits cleanliness_audits_operator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cleanliness_audits
    ADD CONSTRAINT cleanliness_audits_operator_id_fkey FOREIGN KEY (operator_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: cleanliness_audits cleanliness_audits_pump_station_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cleanliness_audits
    ADD CONSTRAINT cleanliness_audits_pump_station_id_fkey FOREIGN KEY (pump_station_id) REFERENCES public.pump_stations(id) ON DELETE SET NULL;


--
-- Name: cleanliness_audits cleanliness_audits_resin_spec_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cleanliness_audits
    ADD CONSTRAINT cleanliness_audits_resin_spec_id_fkey FOREIGN KEY (resin_spec_id) REFERENCES public.resin_specs(id) ON DELETE SET NULL;


--
-- Name: daily_checklists daily_checklists_operator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_checklists
    ADD CONSTRAINT daily_checklists_operator_id_fkey FOREIGN KEY (operator_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: device_readings device_readings_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_readings
    ADD CONSTRAINT device_readings_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(id) ON DELETE CASCADE;


--
-- Name: device_tag_maps device_tag_maps_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_tag_maps
    ADD CONSTRAINT device_tag_maps_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(id) ON DELETE CASCADE;


--
-- Name: devices devices_pump_station_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_pump_station_id_fkey FOREIGN KEY (pump_station_id) REFERENCES public.pump_stations(id) ON DELETE SET NULL;


--
-- Name: devices devices_reactor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_reactor_id_fkey FOREIGN KEY (reactor_id) REFERENCES public.reactors(id) ON DELETE SET NULL;


--
-- Name: downtime_logs downtime_logs_operator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.downtime_logs
    ADD CONSTRAINT downtime_logs_operator_id_fkey FOREIGN KEY (operator_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: downtime_logs downtime_logs_pump_station_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.downtime_logs
    ADD CONSTRAINT downtime_logs_pump_station_id_fkey FOREIGN KEY (pump_station_id) REFERENCES public.pump_stations(id) ON DELETE SET NULL;


--
-- Name: daily_checklists fk_daily_checklists_pump_station_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_checklists
    ADD CONSTRAINT fk_daily_checklists_pump_station_id FOREIGN KEY (pump_station_id) REFERENCES public.pump_stations(id) ON DELETE SET NULL;


--
-- Name: floor_messages floor_messages_operator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.floor_messages
    ADD CONSTRAINT floor_messages_operator_id_fkey FOREIGN KEY (operator_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: floor_messages floor_messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.floor_messages
    ADD CONSTRAINT floor_messages_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: lot_verifications lot_verifications_operator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lot_verifications
    ADD CONSTRAINT lot_verifications_operator_id_fkey FOREIGN KEY (operator_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: lot_verifications lot_verifications_production_log_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lot_verifications
    ADD CONSTRAINT lot_verifications_production_log_id_fkey FOREIGN KEY (production_log_id) REFERENCES public.production_logs(id) ON DELETE SET NULL;


--
-- Name: lot_verifications lot_verifications_pump_station_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lot_verifications
    ADD CONSTRAINT lot_verifications_pump_station_id_fkey FOREIGN KEY (pump_station_id) REFERENCES public.pump_stations(id) ON DELETE SET NULL;


--
-- Name: lot_verifications lot_verifications_resin_spec_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lot_verifications
    ADD CONSTRAINT lot_verifications_resin_spec_id_fkey FOREIGN KEY (resin_spec_id) REFERENCES public.resin_specs(id) ON DELETE SET NULL;


--
-- Name: production_logs production_logs_operator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_logs
    ADD CONSTRAINT production_logs_operator_id_fkey FOREIGN KEY (operator_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: production_logs production_logs_pump_station_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_logs
    ADD CONSTRAINT production_logs_pump_station_id_fkey FOREIGN KEY (pump_station_id) REFERENCES public.pump_stations(id) ON DELETE SET NULL;


--
-- Name: production_logs production_logs_resin_spec_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_logs
    ADD CONSTRAINT production_logs_resin_spec_id_fkey FOREIGN KEY (resin_spec_id) REFERENCES public.resin_specs(id) ON DELETE SET NULL;


--
-- Name: reactors reactors_assigned_pump_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reactors
    ADD CONSTRAINT reactors_assigned_pump_id_fkey FOREIGN KEY (assigned_pump_id) REFERENCES public.pump_stations(id) ON DELETE SET NULL;


--
-- Name: reactors reactors_current_resin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reactors
    ADD CONSTRAINT reactors_current_resin_id_fkey FOREIGN KEY (current_resin_id) REFERENCES public.resin_specs(id) ON DELETE SET NULL;


--
-- Name: sheet_targets sheet_targets_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sheet_targets
    ADD CONSTRAINT sheet_targets_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict wg8o3RyU0cDIFNBgbbhcEmpxSPXO5S8IdSefX0LOz2g7NKwwnhv2QY8NwnFZbY4

