# Formlabs MES — Changelog

What got added and what got fixed, newest first. One entry per day, and where a day had several releases in it the version numbers are marked inside the entry.

Three version numbers are missing. 3.16, 3.26 and 3.26.1 only changed the handbook, the operator guide and this file. Nothing in the app moved on any of them, so there is nothing to write down here. The app currently reads 3.26.1, and the newest release that actually changed it is 3.25.1.

Anything before August 31 is written up from the short notes I made at the time. Some days had two or three releases in them.

---

## 3.19 – 3.25.1 — Monday, September 7, 2026
**The last day before the floor test**

Nine releases. I have put them under one heading and sorted them by subject rather than by release, with the version numbers in brackets so I can still find any of it in the history.

### Making it look like a 3D printing company's app *(3.19)*

We print things for a living and the software did not show it anywhere. None of this changed how anything gets recorded.

- **The wall display builds a resin cartridge as the shift pours.** It fills from the bottom as output climbs toward the shift target, with layer lines on the part that is done and the laser sitting on the layer being written. There is no number to read. You can see how the shift is going from the far side of the floor.
- Nothing on it loops. The page reloads itself every ten seconds, so a repeating animation would restart mid-cycle every time and look like a fault. The height is a value that slides when the number actually changes and sits still when it does not. If it moves, something happened.
- Progress bars are laid down in slices now instead of one solid block. Same reading, and it looks like ours.
- The sign-in screen leads with a Form 4 and a laser passes over it once as the page loads. Once, not looping.
- All the pictures are our own product renders. Nothing in here draws a Formlabs machine, it just positions and reveals the real ones.

### Pouring an amount instead of counting containers *(3.20)*

The record could only say how many containers got filled and then multiply by a fixed size. That is right for cartridges and jugs and wrong for anything decanted. There was no way to write down "we put 180 litres into a drum". So it went in as the wrong number of cartridges, or it did not go in at all. Either way the tank it came out of was wrong from then on.

- New container format, **Drum / Tote**, that takes an amount in litres or kilograms. The container count is still there as a small box that defaults to 1, because three identical drums off one tank is one thing that happened and I do not want anyone writing it three times.
- Converting kilograms needs a density, and the density was already sitting in the spec table without being called that. 1,110 g in a 1 litre cartridge and 5,550 g in a 5 litre jug are the same 1.11 kg per litre. The screen tells you what the amount works out to before you submit. You know you poured 200 kg. That it is 180 litres is the app's claim, so it should say so.
- **The amount gets checked against the tank.** Nobody types 2,500 cartridges and believes it, so a container count checks itself. But 1800 typed instead of 180 looks completely normal, and you find out an hour later when the vessel reads empty on the wall. More than the tank holds is blocked. More than the record thinks is left is only a warning, because a tank topped up before the new lot got logged really can give out more than the record says.
- Off by default. Until you switch it on, the container list has the same four entries it always had.
- One definition of what a log row is worth now feeds the tank levels, the shift totals, the wall display and the exports. A drum counted by one screen and not another gives you two believable numbers and no way to tell which one is wrong.

One bug caught before it shipped. The form picked its format by matching text, and "RPS (5L Bulk Jug)" has the word "Bulk" in it. Adding the drum option quietly turned every 5 litre jug into a measured pour and stopped lot-checking them. All 69 of the new sums passed while that was broken. The interface tests caught it.

### The Google export, which took me four goes *(3.21 – 3.23)*

It was broken because the destination was one line in a settings file, and that line was not set on this install at all. So the page could only ever say "webhook missing", and the fix lived on the server where nobody standing at the page could get to it.

- **Anyone can link their own spreadsheet now.** Name it, paste the address, choose whether other managers can send to it. Yours stays private unless you share it.
- A Google Sheet link cannot receive rows. It is a document and it has no inbox. The sheet needs a small script published as a web app, and that address is the one that goes in the box. Everyone pastes the spreadsheet link first because that is the link they have, so the page spots it, says why it will not work, and hands over the four steps and the script.
- **A success code is not proof anything arrived.** A web app that is not published for everyone answers with a sign-in page and a success code. The export would have told me it sent several hundred records into a login form. Every reply from the script is signed now and only that signature counts.
- **The page was also telling me how many rows it sent, not how many arrived.** Those are two different things and I was printing the wrong one. A payload that reached the script and did nothing still came back looking fine. The script now reports what it actually wrote, read back off the sheet, and names the spreadsheet it answered from with a link. That link is the only thing that would show rows landing in the wrong sheet.
- The script stamps its own version on every reply. The usual way this breaks is a deployment still running last week's code, because saving the script editor publishes nothing and Google never mentions it.
- **Then a 401 that no setting could fix.** A work Google account belongs to a company Workspace, and Workspace admins normally forbid publishing a web app where anyone can reach it. So the page leads with **Excel and CSV downloads** now. No account, nothing to publish, nobody's permission to ask for, and the file opens straight into Sheets or Excel. It sits above the push because it is the one that cannot fail.
- The time period picker never did anything. All four options exported every log ever recorded, so "Live Today" on two years of history sent two years of history. It filters now, and the row count is printed above the button.
- One more of mine. Excel needs a package that was not installed here, and the download button builds its file while the page loads rather than when you press it. So the missing package did not fail a download, it took the whole page down. It only showed up once a wider date range gave the button some rows to work with. Something that only breaks once there is data in it will pass every check you make while writing it. CSV needs nothing, so that one is always there.

### Two things quietly doing nothing *(3.24, 3.24.1)*

**The messaging tab was promising somebody was listening.** Nothing in this app tells a manager a message has arrived. Not the home screen, not the sidebar, not the wall display. A manager sat at the PC all day would never know. But it was called "Direct Manager Communications", drawn like a chat, and sitting on the operator's screen. An operator typing "pump 2 is leaking" and going back to work thinking it was reported is the app swallowing something urgent. The data settles it, four messages ever, all from my account, all saying "test". It is called **Note to Management** now and says before you type that nobody is watching it live and to use the radio for anything urgent. I deleted nothing. Whether it earns a proper alert should come out of whether anyone uses it during testing.

**Log Out looked like it did nothing.** It was revoking the session and clearing the cookie fine, but the signed-in screen stayed up until you hit refresh, so an operator handing a phone to the next shift had no way to know the account was actually signed out. Writing a cookie makes the browser reload the page, so the line after it never ran, and that line was the one that forgot who was signed in. I swapped the order. Nine logout buttons also had a line after "go to the home page" that could never run.

### Weekends, and phones *(3.25, 3.25.1)*

- **The stopped-record alarm did not know it was Saturday.** It asks the shift clock whether a shift is running, and the clock only knew what time it was. Every day looked like a working day, so Saturday at six in the morning read as Shift 1 running with nothing logged, and the wall put up an alarm about a weekend. Every week. If it fires when nothing is wrong then by Monday nobody reads it. There are seven checkboxes under IT Admin now for the days the plant runs. A shift counts by the day it starts, so a Friday night shift is still watched into Saturday morning. It defaults to every day, so I need one visit to IT Admin to switch the weekend off.
- **Half the operator form was off the side of the phone.** I measured it at 390 px wide. The four tab labels wanted 642 px of room and had 358, so only two of them were visible. The other two sat off the right edge behind a scroll nobody finds. They are Pouring, Downtime, Audit and Notes now, and all four fit.
- Three other things I measured on a phone and left alone until real operators have used it. The form is four phone screens tall with Submit two screens down. Tap targets are under the recommended size unless glove mode is on. And the startup checklist asks for camera permission first thing every morning.

---

## 3.18 — Sunday, September 6, 2026
**Getting the app ready to be carried onto the floor, and moved twice**

Testing starts next week. A laptop on the floor first, then a permanent PC. That is two moves, and the second one carries real production data.

- New `Check_This_PC.bat`. One page saying whether a machine is ready to run the plant, and if not, exactly what to type. Python and every package, the database reachable and at the right version, disk space, and port 8501 free. It takes a real backup while it is there, because nobody had ever actually taken one.
- It compares the two Postgres versions. The backup tool cannot read a database newer than itself, and that error only shows up halfway through a restore without ever mentioning versions.
- **The firewall is the most likely reason the phones will not work.** The app prints a confident web address and the handsets just time out. The app cannot spot this itself, because a blocked request never arrives and there is nothing to log. Windows normally asks once, but that prompt often gets blocked by work-laptop policy or hidden behind a window. The check looks for the rule and prints the command to add it.
- Give the phones the machine's name, not its number. A laptop's number changes when it rejoins the network and every bookmark made from the old one dies. That looks exactly like the app breaking. Both are printed, with the name marked as the one to write on the card.
- A restore is checked now instead of trusted. "Restored successfully" only means the restore tool did not complain. A dump can be cut short, a restore can be pointed at the wrong database, or one table can fail while the rest go through. The first sign of any of that is a month with a hole in it. Every backup writes a list of what the database held, and setup compares that against the restored copy table by table. If anything is short it stops and says not to start logging yet, because the old machine still has the data.
- Older dumps taken before those lists existed get skipped, with a reason. More rows than the backup is not a fault, since the plant may have carried on working.
- Every check that can fail also prints its fix.

---

## 3.17 — Sunday, September 6, 2026
**Two things failing where nobody is looking**

- **Backups happen on their own now.** The backup function always worked, but nothing ran it on a schedule, so whether the data was protected came down to whoever last pressed the button. There is no scheduler on a floor PC, so the check rides on the app being opened. If the newest backup is over twenty hours old, take one. The last fortnight is kept, because a full disk is the same outage backups exist to survive.
- IT Admin shows the state. Green with the age of the newest backup, orange when it is days old, red when there has never been one. A section with nothing but a button on it does not tell a manager whether the plant is protected.
- The clean-up only deletes files matching this app's own naming, so a payroll spreadsheet left in that folder is safe.
- **The app notices when nothing is being logged.** The usual failure here is not corrupted data. The PC reboots and the database does not come back, or the app gets closed and nobody reopens it. Every figure still looks normal, because they are all worked out from the log and the last good hour is still the last good hour. The floor finds out when somebody tries to log. Management finds out weeks later. After about three hours with nothing logged during a running shift, the SCADA page says so at the top and the wall display carries a band the size of the wall.
- Silence outside shift hours is not treated as a fault, and a shift that has just started does not get blamed for last night's gap.

Two bugs caught in that work before it shipped. A backup dated in the future was treated as brand new, which would have stopped every real backup until the clock caught up. And the freshness check compared a timestamp with no time zone against one with a time zone, which crashed the home page. Getting that one wrong the other way would have been worse, because the sum would have worked, every log would have read four hours old, and the alarm would have fired all day.

Also deleted some dead code. `Home.py` still carried its own add- and delete-reactor functions, which did not know about vessel type, asset tag or bay marker. Anyone wiring them up would have created half-configured vessels. And the shift clock moved out of a page into `shift_clock.py`, because the wall display needed to know whether a shift was running and the only correct answer lived inside a page.

---

## 3.15 — Saturday, September 5, 2026
**The fleet wall redrawn as the vessels actually out there**

I took photographs of the supply vessels and pump carts. They turned out to be three completely different things, and the page had been drawing all of them as the same rounded rectangle.

Every fabricated vessel is built the same way. A bolted top flange, a barrel, a dark band at the joint, and a cone bottom in a steel frame. Only the totes are flat-bottomed. What differs is shape and marking. M-205 and the White V5 beside it are tall and narrow with litre marks painted up the barrel, 200 to 4,400. M-101 is short and wide with ribs down the cone and no printed scale, just two hand-written marks near the rim. The small one is a caged ULTRATAINER tote on a pallet with a red ball valve, about 1,041 L, flat bottomed.

- **Capacity cannot tell those apart.** M-205 and the Black V5 vessel are similar sizes and different shapes, so vessel type is a stored setting now instead of a guess off capacity. Migration 0011 fills it in from the old capacity bands so an existing fleet draws the way it did before, and a manager corrects the wrong ones.
- The litre marks are the best idea in the photographs, because that is what the operator reads the level off. The tall reactor carries the same scale now, and the drawn liquid lands on the mark somebody at the vessel would read it against. 2,193 L sits just above the 2,000 line, on screen and in the aisle. The squat mixer gets no scale, because the real one has none.
- **The cone shape is in the arithmetic, not just the outline.** Below the joint the surface rises more slowly than the volume, because the vessel narrows underneath. A straight line would make a nearly empty vessel look a third full. That is also why half a tank does not sit half way up one of these.
- The liquid takes the resin's own colour instead of a fixed blue. A near-black resin is lightened until it reads as liquid rather than a hole, and the percentage over it switches between black and white text depending on what it sits on. White V5 and Black V5 are both in this fleet.
- Each vessel is stencilled with a tag (M-101, M-205) and stands beside a bollard with an orange bay marker (E2, F3). Two optional fields, drawn where they are in real life. A tank called "Reactor 2" on screen and "M-205" in the aisle is one translation step right at the moment somebody is checking whether the screen is telling the truth.
- A vessel with no resin says IDLE instead of 0.0%. It is not nought percent full of anything, and a number there sends somebody looking for a leak.

One caught before it shipped. Colour gradients are referenced by name, four vessels share one page, and duplicate names all resolve to the first. So every tank after the first would have drawn the first tank's colour, at the right level, on a wall whose whole job is being recognised by colour from across the room. Nothing would have looked broken.

---

## 3.14 — Saturday, September 5, 2026
**The reactor levels were never a reactor feature**

Reported from the floor. With work orders disabled, the Live Reactor page was confidently wrong. Every tank drained to empty on the first day and stayed there, and the figures on the way down were understated by up to five times.

A reactor record holds a name, capacity, status, resin and pump. There is no fill level on it, so the level was always worked out. The problem was what it was worked out from. The assigned work order was quietly doing two jobs that are not work-order jobs. Its lot number answered when the tank was last filled, and its container format answered how big each unit is. Take it away and both answers vanish, so the page added up every log ever recorded for that resin and pump, and sized every one as a 1 L cartridge.

I reproduced it on a throwaway database first. A 5,000 L tank with two lots behind it read 4,000 L remaining with a run present and 400 L without. A 3,000 L tank drawn down in 120 five-litre jugs read 2,400 L with a run and 2,880 L without. 600 litres counted as 120.

- **The fix is that operators already tell us both things, every hour.** The lot number goes on every hourly log, so a new lot at a station means that tank was refilled. Every log also carries the container it was poured into, so litres get added up per log instead of assumed. No new field, no new screen, nothing extra for anybody to enter.
- It reads the same in both modes, because dispatching a run puts the same lot on the run and the log.
- Container volumes have one definition in `crud.py` now, replacing seven copies of the same expression across the reactors page, Home, the TV dashboard and the Google sync. With seven places to edit, sooner or later the totals and the tank levels disagree.
- Both level calibrations were rebuilt the same way. They divided the correction by a container size read off the work order, so with no run they assumed 1 L and wrote the wrong adjustment. On a tank nobody had poured from they could not calibrate at all. They work in litres now, and record the difference as an adjustment row belonging to its batch rather than looking like a refill. Dated and attributed, never an overwrite.
- The tank card's second line is the lot instead of the operator, since that is the thing somebody at the vessel can check against the container in front of them.
- The kilogram figure no longer depends on container format. A 1,110 g cartridge in 1 L and a 5,550 g jug in 5 L are the same 1.11 kg per litre. It was only ever a density.

---

## 3.13 — Saturday, September 5, 2026
**Three faults from the floor that only happen in a browser**

No new features. The three have the same thing in common. Each one was an action that needs the browser to receive the current screen, followed straight away by a refresh that throws that screen away. Python saw success every time.

- **"Remember this device" never wrote a cookie. Not once, on any device.** The cookie library does not write from Python. It renders a small component, and the browser has to receive that screen and run its code. A refresh on the very next line tore it down first. The library also updates its own in-memory copy, so the same run read the value back and everything looked fine. I checked in a browser and there was nothing in the cookie jar but Streamlit's own token.
- This was every cookie in the app. Nine places set a cookie and immediately refresh, so a chosen theme reset on the next visit, glove mode would not stay with a terminal, night dimming would not stick, and the operator's remembered pump station was never remembered.
- Fixed once in `utils.set_cookie`, which writes the cookie and then waits for the browser. 1.2 seconds, measured rather than guessed. At zero, not one cookie is written. At 1.2 all of them are, on desktop and phone. You only pay it on actions that write a cookie, and an operator opening the terminal triggers none.
- One guard came out of that. The "remember my station" cookie was compared against a value that is empty on the first run of a fresh page load, so it decided the cookie was wrong and rewrote it. That charged every operator the wait on the screen they open all shift, for a value that was already correct.
- **The confirmation after submitting a log was not appearing.** Same shape. A pop-up belongs to the current screen, and the refresh straight after can throw it away before the browser paints it. Desktop usually won that race. A phone reliably lost, so the operator at the pump submitted an hour's count, got nothing back, and had to open the last submission to check it existed. Every hour.
- Confirmations go through `utils.flash` now, which stores the message so it survives the refresh and shows it at the top of the next screen. I made it a banner instead of a pop-up on purpose. A banner stays until the next action. A pop-up vanishes after four seconds whether or not anybody was looking, and looking away is what an operator does between screen and pump. Eleven of them moved over.
- **The QR checksheet button was on the wrong side of a wall.** The startup checklist asks the operator to confirm they have scanned the daily station QR code, and the button that opens it sat behind the gate they cannot pass until they tick that very box. So entering the address in IT Admin looked like it did nothing.

---

## 3.12 — Friday, September 4, 2026
**One switch decides what this is: a logging system or an execution system**

The app worked with no work orders and told the operator it was broken for it. A plant that had not set one up got a heading with a manager's name over an empty space, a box telling it to find a manager, a yellow warning on every log, a warning pop-up after every submit, and a floor display announcing "No Work Orders configured" to a room, all shift. Five sentences all saying the same untrue thing, that something is missing here. Nothing was.

- **A simple mode setting (migration 0009), on by default.** On, the operator terminal is station, material, lot, counts. Off, every work-order screen comes back exactly as it was, and nothing entered is lost either way.
- The work-order parts are hidden once at the top of the operator page instead of checked in four places. That is why a stale run left open in the database cannot raise DO NOT POUR on a terminal with no way to show what it means. With no run to compare against, the lot check records instead of comparing, which is still the whole traceability answer.
- **A manager is the administrator now, unless the plant says otherwise.** A plant small enough not to dispatch work is small enough not to have an IT person. As a logging system a manager holds the whole console. Accounts and PIN resets, pumps, resins, settings, backups, cleanup. As an execution system, administration goes back to administrator accounts.
- The rule is one function, `crud.can_administer`, asked by eleven places across eight files instead of comparing text to `"admin"`. With eleven copies of a permission check, one of them ends up disagreeing with the other ten.
- Two guards, because this is a permissions change. Switching to execution mode with no administrator account would leave nobody able to reach the console, including to switch back. That save is refused with a message saying what has to exist first, while every other setting still saves. And a manager arriving at the console is told why they have it and what takes it away.
- The sign-in screen follows the mode. It read SCADA TERMINAL over MANUFACTURING EXECUTION SYSTEM, which is the largest claim the app makes, on the first screen anyone sees. As a logging system it reads POURING LOG over RESIN POURING · PRODUCTION RECORD.
- **The shift handover is gone (migration 0010).** It emailed four whole-day figures as a PDF. All of them are on the landing screen broken down by station, operator, resin and shift, which the report was not. It filtered by date, so the second shift's handover quietly included the first shift's work, and a night shift crossing midnight split across two reports. The incoming lead arrives before the shift and opens the app anyway. It was also the only feature that needed an outside email account, which made the least useful screen the most expensive to set up.
- Found next door while removing it. The Google Sync page offered a manual push, an auto-sync on shift handover, and a scheduled webhook. Only the first one existed. The choice was never read except to word the spinner, and one option was named after the screen I had just deleted.

Two real bugs fell out of the mode work. The recorded-lot message read back `L-L-2411A0742` with the prefix doubled, on the one screen whose whole job is being trusted about a code. And the settings save handed the database a value type it refuses, which loses the whole save. Unticking the packing option would have hit that the first time.

Two on the housekeeping side. Of forty-one top-level Python files, about twenty were the app. The rest were screenshot scripts, document builders and a retired installer sitting beside the code as if they ran on the floor. They live in `dev/` and `docs/` now, and `Move_To_New_PC.bat` excludes those folders instead of a filename list that goes stale.

And first-time setup defaults to a clean database now. `Setup_On_New_PC.bat` refused to run without a backup and always restored it, which would have put the development database, demo operators included, on the plant PC. A backup is an offer now. With none, the app builds its own database and seeds one administrator, three placeholder pumps and the downtime reasons.

---

## 3.11 — Thursday, September 3, 2026
**A readiness pass before testing at the plant**

No new features. The honest answer on whether the build was floor-ready was not yet. There were four faults the existing tests could not see, three of them because the tests fake out the very thing that was broken.

- **A restored backup would not have started.** The startup routine had three cases and only two of them ended on the current schema. A database with the app's tables but no recorded version, which is what an older backup restored onto another machine looks like, was marked as being at the starting version instead of being brought up to date. The app then ran seven revisions behind and died on the first settings read. Marking says where a database already is. It does not update it. This is the path `Setup_On_New_PC.bat` takes.
- **The IT Admin console was dead for every admin.** One sidebar line linked to a page it could not find, and that raises an error. The navigation renders near the top, so the whole console was an error page. The page sweep could not catch it because that harness fakes out page links. I found it by opening the page in a browser.
- A new source-reading check confirmed all 178 navigation targets across 20 files are real. It also flags pages nothing links to, which found the Theme Gallery, built and then left reachable only by typing its URL.
- **Every form label was almost invisible on the dark themes.** Streamlit colours anything a theme does not, using a value picked for its own light theme, so widget labels, navigation links and the popover button kept a near-black default on a dark background. Measured: nav links 1.35:1, widget labels 1.14 to 1.68:1, the preferences button 1.01:1, against a readable floor of 4.5:1. Worst on a phone, where the six nav buttons are the entire navigation. Fixed once in the shared stylesheet instead of in thirty-four themes. Measured afterwards across ten themes, 9.1:1 to 18.9:1.
- **RPS jugs are gated like every other format now.** They were the one exception, on the understanding that bulk jugs carried no lot label. They always have, and the plant has since made tagging before pouring a rule. The exemption that showed the expected lot on RPS is gone too.
- The wording follows the container, and only the noun differs. Cartridges and jugs carry the same label in the same place, on the bottom of the empty, so the check and the instruction are identical. On a jug the section reads *Jug Lot Verification*, *hidden on purpose, read the jug, not the screen*. It follows the container picker rather than the page, so switching format mid-session flips every one of those words.

The browser tests came out of this. The existing ones run the pages but render nothing, so none of them can see a control that is off-screen, a click that does nothing, or a page that failed after it drew. The new one drives a real browser through an operator's first hour, then does the whole thing again at phone size.

---

## 3.10 — Wednesday, September 2, 2026
**Fill weight, two shifts, light themes, and a floor-usability pass**

- **The app has always known the target fill weight and never once recorded a measurement against it.** The resin specs carry the target and the allowed range, 1110 g, accept 1100 to 1115, so it could say how many units were poured but not how much resin went into them. There is an optional check-weight box on the hourly form now (migration 0006) and a fill-weight section in Analytics.
- Passing the check and giving away resin are the same reading. A pump set to run safely clear of the low limit sits above target on every cartridge. Inside spec, passing every check, handing over free resin every time. Four of the sixteen specs make it worse by being lopsided, but it happens on an even range too. Every gram above target is about 0.09% of the fill, so 4 kg per thousand cartridges at 4 g heavy.
- **The reading is optional and can never block a submission.** A wrong lot is a defect. A heavy cartridge is information. Make it mandatory and within a week it is the target typed from memory on every log, and then the column is full of `1110` and looks like real data. It is never pre-filled either, for the same reason the run card had to stop printing the lot the gate was hiding.
- One field, not the three the paper form asks for. Three cartridges weighed in the same minute mostly measure the scale's noise, and the variation worth catching is between hours. The analytics weight each reading by the units logged alongside it, which turns "+3 g" into kilograms. The verdict is stored against the resin's range at the time, so editing a spec later cannot re-judge old readings.
- **The plant runs two shifts, not three.** The app assumed three and offered "Shift 3" everywhere. Rather than hardcode two, which only moves the wrong assumption, the count is a plant setting (migration 0007, default 2). Logs written when three shifts were offered keep their label and stay in every report.
- Found while generalising that. The gateway could not work out which shift 01:30 belongs to. It sorted the start times and took the largest match, but 01:30 is earlier than every start time, so the answer fell out of list order rather than any reasoning about midnight. The last shift of the day owns everything until the first one begins next morning.
- **Ten new themes, six of them light.** Not one of the original twenty-four was light, which is a real gap on a brightly lit floor where a dark screen is a mirror. New themes are a palette of about a dozen colours instead of fifteen hand-written rules, so a new component is styled once instead of twenty-four times. The original twenty-four are untouched, because people have preferences saved against them by name.
- The contrast checker found two real failures in existing themes. Card labels were 3.9:1 in Default Dark, the theme most people look at, and 3.0:1 in Dracula. Both below the floor, both fixed.
- **Resin chips carry a texture as well as a colour.** Five pairs across the palette are the same colour to the eye, like Clear V4 and Rigid 4000, or Black V4 and Tough 1500. Those colours came off the plant's own sheet, where each one sits beside a full row of text. Shrunk to a chip, colour was carrying more than it can, and a Clear/Rigid mix-up is what the lot gate exists to catch. The texture comes from the resin family, so Clear V4 and Clear V4.1 still match while Clear and Rigid cannot. It survives greyscale printing and colour blindness.
- Patterns are assigned rather than worked out from the name, which collided where it could least afford to. Rigid 10K and Rigid 4000 look alike, carry target weights 370 g apart, and drew the same texture.
- **Glove mode.** Operators handling resin wear nitrile. Touch still registers but precision drops, and the form asks for number steppers and a lot field. A toggle pushes every target past the accessibility touch size and scales the type. Stored against the terminal, not the account, so a shared floor terminal keeps it for whoever signs in next.
- **Night dimming**, based on the plant's own shift times instead of a fixed hour, since "night" here means "not the day shift". It is a brightness and warmth reduction rather than new colours, so it works with all 34 themes. Photographs are exempt so a stamp under review keeps its true colour. What people reach for otherwise is turning the monitor down, and that destroys the colour coding the lot check depends on.
- **Undo on your own last log.** A typo, 2500 where 250 was meant, needed a manager to open Log Management, so the wrong number sat in every dashboard until somebody found it. Two minutes, own row only, latest row only, and never a flagged log, because that flag is a cartridge problem somebody may be reviewing. Run progress is recalculated from the surviving logs.
- **Focus mode.** During a pour the operator is at the pump, not the screen, and the four things they need, resin, lot, count so far and how many left, are scattered across a card, a progress bar and a form. One toggle replaces the page with those four, large enough to read from across the station.
- The pouring form says whether the log actually saved now. The write was unguarded. If the database was unreachable the page failed or quietly re-ran, and an operator who is unsure re-submits. A duplicated hourly count does not look wrong afterwards, so nobody catches it, and the network drops in parts of this building.
- **Operators are on their own phones, not a station tablet, and the app was pushing the page off the screen.** Two files forced the sidebar open, which on a 390 px handset covered four fifths of the page, so the first action of every hour was closing something nobody opened. It is automatic now. Open on a desktop and the wall display, closed on a phone.
- **The pump form is a button inside the app now instead of a sticker on the pump.** Scanning the QR code works but it is a one-way trip. The phone navigates away and the way back is the browser's back button, which costs the session and whatever was half-typed. A link button opens the same form in a second tab, so closing it puts the operator back mid-log. The address is a plant setting (migration 0008), because this app does not own that form.
- Addresses are checked where they are typed. The two real pastes are a bare host with no `https://`, which the browser resolves against this app and lands on a "not found" that looks like the app is broken, and a line lifted out of an email with a full stop on the end. Both get repaired. Anything that is not http or https is refused, including `javascript:`, which has no `://` and would otherwise have slipped through.
- **A setting that saved and was never read back.** `shift_count` had a column, a migration, an admin field and a working save, and the settings reader never returned it, so every picker fell through to the default. That default happened to be two, which is right for this plant, which is why nobody noticed.
- Five pages rendered nothing at all with no data. Scrap Intelligence, Historical Trends, Cleanliness, and both charts on the yield page. Most of the rest said something like "No assigned runs currently active", which states the obvious and leaves the reader stuck. Every empty screen says what will make it fill up and the next step. Not styled as an error, on purpose. Having no data yet is normal on a system installed last week, and painting that red teaches people to ignore red.
- Every light theme had white text on a cream card. The palette work removed hardcoded colours from the theme engine but not from the page markup. The worst was the filter header on the landing screen, the first thing anyone sees. Eighteen of these take their colour from the theme now.
- Every light theme also showed its own stylesheet as visible text. Streamlit passes stylesheets through a text formatter that treats an indented line as example code, so an indented style block added after other content gets shown instead of applied. Found in a browser after the tests passed.
- The in-range headline was rounding away the exception. 349 of 350 readings in range is 99.71%, printed as a clean `100%`, directly above a chart where the one out-of-range point is right there to see, and that point is the reason to open the panel. Only a real clean sweep reads 100% now.
- Pulled the repeated markup into `components.py`. Cards, stat tiles, notes and section headers were hand-written HTML copied page to page and drifting a little each time.

---

## 3.9 — Tuesday, September 1, 2026
**Resin colour identity everywhere a resin is named**

Every place the app prints a resin now prints it in that resin's colour. People on the floor recognise a formulation by the colour of its label long before they read the words, and the plant's master sheet has been colour-coded that way for as long as it has existed. The app was the only thing in the building showing every resin in identical grey.

- The operator's selection, run cards, reactor tanks, the TV board, the lot-verification feed, the log tables and the spec lookup all carry the same coloured chip. The Analytics donut and Scrap Intelligence bars use those colours instead of the chart library's defaults. A chart that invents its own palette teaches a second colour language for the same things.
- **The colours are the plant's own**, sampled off the master sheet, so the screen and the sheet on the wall read as the same document. Thirty-four formulations matched by name.
- A resin nobody has listed still gets the right colour, because "a manager sets one" means every new resin is grey until somebody remembers. Formlabs names resins by family and revision, like Black V4, Black V4.1, Black V5, so an unlisted name is matched on its family. Add Black V6 tomorrow and it is the correct grey-black straight away. The rules are ordered most-specific-first, because these are partial text matches and "Clear Cast" also contains "Clear", "Grey Pro" also contains "Grey", and "Fast Model" also contains "Model".
- Anything matching no family is assigned one of forty prepared swatches, worked out from the name using md5 rather than Python's own hashing, which changes between restarts and would give the same resin a different colour every time the app starts.
- A manager can override any of it. Resin Canvas gained a colour picker, pre-set to whatever the resin resolves to today, so saving without touching it cannot quietly change anything.

**The `color_tag` column already existed, and real data showed it had never meant what I assumed.** I wrote migration 0005 to fill in rows still holding the old shared orange default, then restored an actual backup to rehearse the move. The column holds a container format colour, not a material one. One green on all forty RPS rows, one blue on all eighteen V1s, one rose on every Pigment. My migration read those as somebody's choices and left them, which would have shipped a feature where most resins render as one of six identical blocks. An empty-database test passes happily through that. Only real data showed it.

So I rewrote the migration around what actually separates the two. An identity is not shared. A colour worn by three or more distinct resin names is labelling a group and gets replaced. One worn by one or two is somebody's decision and gets kept. Distinct names rather than rows, because the same material legitimately has one row per container size. On the real table that turns 67 resins sharing 6 category colours into 33 real ones. Running it twice changes nothing the second time.

Three fixes to the move-to-a-new-PC scripts the same day:

- `Setup_On_New_PC.bat` marked the database as current after restoring it, but the dump carries its own version, and marking overwrites that without running anything, so every migration added since the dump would be silently skipped. Replaced with a call into the app's own startup routine, so setup and boot are the same code.
- `run_mes.bat` launched with the system Python rather than the one setup installs into, which works where packages happen to be installed globally and fails with "No module named streamlit" anywhere else, which is what a fresh PC is.
- `install_mes.bat` pointed at a file that has not existed since the app was reorganised, and tried to download and silently install Python from the internet, which is not something to run on a managed work PC.

Also a Postgres version check on the same script. This database is 18, and an 18 dump uses syntax older versions cannot read. Hand it to a version 16 tool and the restore dies on line 5 with a message that says nothing about the actual problem. And an optional offline-packages step in `Move_To_New_PC.bat`, because a work PC often cannot reach the package servers and that failure arrives several minutes into setup as a wall of red text.

---

## 3.8 — Monday, August 31, 2026
**Cartridge lot verification, per-station checklists, and the credentials out of git**

- **Closed the hole behind the lot mix-ups on the floor.** The pouring form used to fill the run's lot number into an editable box, so the form answered its own question and an operator could log a full hour without turning a cartridge over. The expected lot is hidden now and the operator types what is stamped on the bottom. The comparison ignores formatting, so typing the stamp verbatim (`L-2411A0742`) matches a lot the manager entered bare (`2411A0742`), while near-misses still fail.
- A mismatch never dead-ends the operator. A full-width STOP, then a required cause and details before the log will submit. The log saves flagged, carries the lot that was physically in the cartridge rather than the expected one, and gets an explanatory note. The run's progress bar does not move, on purpose, because a mismatch that still produces a correct-looking count is one nobody notices. There is also a "wrong cartridge, pulled it, nothing poured" button, because a catch is data worth having and there was nowhere to put it.
- **A photograph of the stamp is required on a mismatch, and only on a mismatch.** It started as a requirement on every check, and on a bad network segment here the upload took 20 to 30 seconds each time. The typed comparison is what blocks a wrong cartridge, so the check is exactly as strong without the photo, and half a minute of standing still per check is the friction that teaches operators to resent a control. It is worth thirty seconds on a flagged pour, which somebody reviews later and the operator may have to defend. It is not required to pull a cartridge and log the catch, because the safe action must never be slower than the risky one.
- A fast path so a per-log check does not decay into a reflex tap. A full check on the first log of a shift, on any change of run, lot, resin or station, after 4 hours, and on every 10th log. A one-tap confirm otherwise. A mismatch clears the fast path.
- I did not ask the operator to type the expiry printed under the lot. One field is all of their time this check is worth. The parser and columns are already written, so a later automatic pass over the photographs can fill them in.
- Corrected the stamp format after checking an actual cartridge. The base reads `L-<lot>` and `E-<date>`, not `L:` / `E:`. No functional impact, since the parser already stripped either separator, but every on-screen label said the wrong thing, and that is the kind of detail that makes an operator distrust the rest of the screen.
- New `lot_verifications` table (migration 0003) records every check, pass or fail, with the photo and both codes. New manager page with the flagged feed, per-operator coverage, an expiry watch, and CSV export.
- **The startup checklist is per-station now instead of once per day per shift.** A checklist certifies the condition of the pump you are standing at, so an operator moved to a different pump has certified nothing about it. The lock screen gained a "which pump are you starting at?" picker that feeds straight through to the logging tab. The cleanliness step is keyed by station too, so switching pumps mid-checklist cannot carry the previous station's photo over. Rows written before the column existed (migration 0004) count for any station on that date, so shipping this did not re-lock every operator who had already done their checklist that morning.

The test suite went in the same day and immediately found six things:

- The run card was printing the lot the gate was hiding. The active-run panel sits directly above the verification section and showed the lot in plain text, so the whole gate was decoration.
- Eight pages would crash on a theme change. Six never imported the date functions and two imported half of what they use, but the only call site is inside the theme-change branch, so it only blew up when someone actually switched theme from one of those pages.
- Log Management crashed whenever 1 to 9 records matched. Both row-count boxes were set to the number of matches against a minimum of 10, so a narrow filter or a quiet day made the value illegal.
- The TV dashboard was a hot loop. It ended with a refresh under a comment promising a 10-second wait that was not there, so it re-ran as fast as the machine allowed, several full-table queries per pass, continuously, on a screen that is up all shift.
- A CDN fetch could take down the operator terminal. The run-complete animation was fetched on every refresh with no timeout and no error handling, so a slow CDN or a floor PC that lost its internet would hang the terminal and then fail before one control rendered. Guarded now, 3-second timeout, fetched once per session.
- **The Admin Panel could never save plant settings.** The save function took fifteen separate arguments while its only caller passed a single bundle, so every click failed. That means shift start times, shift lengths, break minutes, rate targets, yield targets and the packing toggle have never been changeable from the interface, and every pace and yield figure is measured against those numbers. Here is how it survived a day of testing. The page sweep loads all 18 pages and reports them clean, but it never clicks anything.

Two more, both structural:

- Closed a cross-site scripting hole in the raw-HTML cards. The app builds a lot of its cards by dropping database values straight into markup, and most of those values are typed by people on the floor. Names, notes, messages, lot codes. An escaping helper at 28 points across 10 files. The non-security half of it is that a note containing a `<` was already breaking the card it rendered in.
- Extracted the page shell, 1,335 duplicated lines gone. Eleven manager pages each carried their own copy of the same 131-line navigation bar, sidebar and account popover. That duplication was the direct cause of the theme-change crash above, since the block had been pasted eight times and half the copies were missing an import. I did a straight lift rather than a rewrite, and every one of the 18 pages renders exactly the number of elements it did before.

Also added read caching, which there was almost none of, so every keystroke in a number box re-ran the whole script and re-queried the database for the resin list, pump list, operator list and settings. Seven reference reads cached. Production logs, runs and lot verifications left uncached, since those must be correct the instant after a write.

And killed the default sidebar navigation properly instead of hiding it. Every page injected styling to hide it after the fact, which is why it still flashed on load. The browser was being sent the nav and told to hide it a moment later. The supported switch needs a config file and the project had none. All 19 styling blocks removed. The new config also stops Python error details appearing in the browser, which is right for a floor terminal.

**Found the credentials sitting in git, and got them out.** The settings file holding the live database password, the email password and the Google Sheets webhook had been tracked since the repository was created and was on the server. The 3.3 entry below says the point of moving secrets into that file was that nothing sensitive sits somewhere it could be shared or committed by accident. That was the right instinct, it just needed one more step. The file was never added to the ignore list, so the file holding the secrets became the file committing them. It is untracked now, with a template committed for setting up a new machine, along with the old database file, a code dump, the runtime log and the editor folder. Untracking does not undo the exposure. The values are still in earlier commits. The repository is private, which lowers the urgency but does not remove it.

---

## 3.7 — Sunday, August 30, 2026
**Machine integration, and a batch of operator fixes**

Started building a real Device Gateway, a back end for wiring pump controllers, bench scales and eventually label printers straight into the app. I did not want to hardcode a protocol, because I do not yet know what our equipment actually speaks. Every machine gets one row in a `devices` table with a protocol column, and the code for each protocol lives behind one shared interface in its own file, so supporting something new is one new file and one line in the registry.

- Six adapters. Modbus TCP (panels on Ethernet, the likely fit for the filling controllers), Modbus RTU (the same over a serial cable), OPC-UA (newer equipment), MQTT (machines publishing to a broker), Serial ASCII (bench scales streaming plain text, matched against a configurable pattern rather than one hardcoded vendor format), and HTTP polling.
- **Machine readings write through the same function an operator's typed entry uses**, tagged "Automated Gateway". Every rule already in the app therefore applies to machine data for free. Run progress, marking a run done, the links to users, stations and resins. Analytics, the Manager Cockpit, Live Reactors and the TV dashboard needed no changes, because they read the same tables and cannot tell a keyboard entry from a machine one.
- A separate `device_readings` table for raw machine data. Fault codes, machine state, weight curves, uptime. Production logs are what the plant is measured on and should not fill up with machine noise, but that noise is exactly what you want when a machine starts misbehaving.
- A shared vocabulary (`normalize.py`) so every adapter reports the same names, and a `device_tag_maps` table holding each device's mapping from its own raw tag to one of those names.
- The poller is its own long-running program rather than part of the app, because the app re-runs a page on every interaction and that is a bad fit for continuous polling. One thread per device at its own interval, rescanning the devices table every 10 seconds so a machine added on the admin page starts polling without a restart. A device that fails does not take the rest down.
- New admin page for finding, registering, test-connecting and mapping equipment. Trying a pattern against real serial output before committing is the difference between an afternoon and a week.

The floor fixes that day:

- An operator's logged bottle counts were not updating their run's progress.
- The progress bar was not filling as production came in. The numbers were right, the bar just was not reflecting them.
- Manually adjusting a run's progress could silently revert on the next refresh.
- The live shift-status indicator sometimes showed a shift as active for hours after it ended.
- An admin testing the app as an operator could accidentally downgrade their own permissions.
- Fixed auto-scroll on the operator logging page, and cleaned up the shift-progress card so it only renders when it is relevant.
- Reworked station assignment so several operators can log against the same reactor and run without a manager creating a duplicate assignment each. Which run shows on your screen follows the pump station you selected rather than the run's assigned operator.
- New Log Management page so managers can find and delete bad or test entries, downtime rows and completed work orders. The bulk cleanup stays disabled until you literally type DELETE into a box.

---

## 3.6 — Saturday, August 29, 2026
**Migrations, real password hashing, and joining up the records**
*Three releases this day.*

- **Replaced the way the database structure changes.** The startup routine had grown a hand-maintained list of thirty-odd raw schema commands, wrapped in one silent catch-all that could not tell "this column already exists" from a real failure. A change that broke looked exactly like one already applied. It is a proper migration history now.
- Hit a crash the moment a database password contained an encoded character. A `%21` for a `!` was read as a placeholder. It would have stopped the app dead on any machine with a password like that.
- **Moved PINs to proper hashing.** They were unsalted SHA-256, which is fast to compute and therefore fast to attack in bulk. Salted bcrypt now, across creation, changes and login. Older accounts are detected and get a clear "needs an IT admin reset" message rather than a confusing failed login.
- Account lockouts. Five consecutive failed PIN attempts locks the account for fifteen minutes. An unknown username returns the identical "invalid credentials" message as a wrong PIN now. Before, the two differed, which quietly told anyone probing the login screen which usernames were real. The staff table shows locked status with an Unlock button, so a lockout clears without also resetting the PIN and interrupting a shift.
- **Renaming an operator split their history in two.** Every log stored the operator as plain text, so the moment a name changed, all their old logs were orphaned from their new ones and Analytics showed them as two people. The root fix was adding real links between records. Operator, pump station, resin spec, sender, current resin, assigned pump, across production logs, downtime, runs, checklists, cleanliness audits, floor messages and reactors. All optional and cleared rather than blocking, so deleting a user or pump cannot break historical rows.
- A backfill fills those links in on data already in the database, and the eight functions that create rows store the link at the moment of writing. New links are worthless if only new data has them.
- The Historical page had the same bug from the other side. The operator filter and the output chart disagreed after a rename, because the chart grouped by identity while the filter still matched raw text, so picking someone from the dropdown showed less than the chart claimed.
- **Backups could have been pointed at the wrong database.** The backup and restore functions had the host, user and database name written in, plus a Windows-only tool path, and ignored the configured address entirely. Point the app anywhere else and the backup silently backs up something else. They take all of that from the real connection address now. I also deleted a stale duplicate copy of both functions that had been shadowing the real ones. That is the kind of thing where you fix a function and nothing changes because the app was never calling it.
- Added actual error logging (`app_logger.py`), then wired it into the error handlers that had been swallowing failures silently. The backfill, resin spec creation, suggestions, reactor creation, and above all backup and restore, which now logs what the backup tool actually said instead of failing with no trail.
- **Profile pictures never rendered.** The filename had been saved on every upload since the feature shipped, and nothing ever read it back. Sign-in, session lookup and the auth check all left it out, and every sidebar drew a hardcoded emoji instead. Fixed across all sixteen pages with one shared helper. Chat threads had it from the other direction, drawing a fixed icon per role, so every manager looked like the same person.
- Fixed the login screen's theme flicker. The saved theme lives in a browser cookie and the read lags the first render, so the screen painted in the default theme and then jumped. The previous workaround was a blocking pause.
- Swept every blocking pause out of the request path. They let a message be read before a page refresh, but the app serves on a shared thread, so each one froze the server for everyone else on the floor too.
- Broke up `database.py`, which was past a thousand lines holding the connection, every table definition, every query and the file helpers. Split into `db_core.py`, `models.py`, `crud.py` and `utils.py`, with `database.py` left as a thin pass-through, which is why not one page had to change.
- Wrote `create_admin.py`, a standalone script that force-creates a properly hashed superuser. It exists for exactly one situation, total lockout or a wiped database, and in that situation having no way in would be the end of the app on that machine.

---

## 3.5 — Friday, August 28, 2026
**The zombie-cookie logout bug, and the app going into version control**

- **Put the whole project under git.** Up to this point the only history was folder copies. This is also the evening the settings file with the live credentials went in with it. See the 31st, where I found it and got it out.
- **Fixed the phantom auto-login loop.** Signing out left a valid cookie behind, so the next page load signed you straight back in. You could not get out of the app, and neither could anyone else on that terminal. Fixed with an explicit signed-out flag that survives the session wipe. The theme preference is kept out of that wipe on purpose, because getting the default theme back every time you log out is a small daily annoyance nobody should have to explain.
- Added a theme picker to the login screen itself, before you are signed in, so the screen you stare at while typing your PIN is already in your theme rather than snapping into it a second later. Small, but the login screen is the one screen every person sees every day.
- Standardised the shell across every page. The navigation, sidebar profile block, preferences popover and release-notes reader had all drifted, because pages were added on different days and each carried its own copy. This is the duplication I deleted on the 31st, and the direct cause of a crash.
- Gave IT Administrators the same equipment rights as plant managers in Live Reactors, so they are not blocked from fixing floor equipment by a check that only anticipated managers.

---

## 3.4 — Thursday, August 27, 2026
**IT Admin console, role-aware navigation, sessions that survive a refresh**
*Two releases this day.*

- **Built a full IT Admin console** for creating and managing accounts, editing settings and recovering from problems, so nothing routine requires somebody opening the database directly. Once you are the only person who understands the database, every small fix becomes your problem forever.
- **Rebuilt navigation to branch on role instead of hiding links.** Admin gets a six-link top bar including the IT console, manager five, an operator a stripped-down set. Before, one navigation served everyone and just hid what did not apply, which leaked what other roles could do and made the operator screen busier than it needed to be.
- **Made sessions survive a hard browser refresh.** The session check happens on initial page load now rather than partway through, so a refresh no longer has a window where the app decides you are not signed in and throws you out mid-shift. This was the single most common complaint about using the thing.
- Added a superuser debug mode so an admin can view the app as another role. It is the only practical way to check what an operator's screen actually looks like without keeping a second account.
- Consolidated account settings into one place. Theme, profile, avatar and the feedback tool had each grown their own home on whichever page they were added to. They live in one preferences popover now.
- Extended the user record to store profile pictures, kept in a controlled folder on the server rather than as arbitrary paths. They did not actually render until the 29th. The write side shipped here and the read side was never wired up.
- Added an app-wide feedback tool routing to an admin inbox, so someone on the floor who hits a problem at 2am has somewhere to put it that is not a text message to me.
- Restored the Google Sheets sync into the management console, with control over which figures are included and a manual "send now" instead of only firing on a schedule.
- Added Master Equipment management to the IT console. Reactors, pump stations and downtime reason codes, all editable in the interface. Downtime codes especially, since those are the vocabulary the whole downtime analysis is built on, and they were previously only changeable in the source code.
- Fixed sign-out properly. Session revocation is guarded so an already-dead session cannot crash the logout, and every module routes back to the login screen rather than leaving you on a page you are no longer allowed to see.
- Overhauled the Analytics screen's styling. Sidebar restored, KPI cards rewritten to use the theme's own colours, and the charts converted to see-through layouts so they read correctly in every theme.
- Hardened the station admin screen against older rows using legacy column names, fixed the collapsed-sidebar controls which were nearly invisible against several themes, and added responsive type sizing so navigation labels stop wrapping when the sidebar expands.
- Added the in-app changelog viewer, this file, visible to anyone using the app rather than only to me.

---

## 3.3 — Wednesday, August 26, 2026
**Access control, confidentiality, and making it usable on a tablet**
*Two releases this day.*

- **Put a real permission check at the top of every page.** Before this the navigation hid links that did not apply to your role, which is not security. Anyone who typed or bookmarked the URL got the page. Now each page checks who is asking and stops if the answer is wrong. This is the change I would point at first if someone asked whether the app is safe to put on the floor network.
- Made login persist properly across pages, so moving between screens stops being a series of small opportunities to get logged out.
- **Moved the resin recipes out of the source code.** Spec weights, tolerances and multipliers were written into a Python file, which is the wrong place for confidential formulation data. It cannot be changed without editing code, and it travels anywhere the code travels. They are in their own table now, and I built the Resin Canvas page so a manager can edit them directly.
- Moved the database address, webhook URLs and mail credentials into a settings file, so nothing sensitive sits somewhere it could be shared or committed by accident. That was most of the way there. It needed one more step, which it did not get until the 31st.
- **The Google Sheets sync had been exporting the raw table**, so internal-only columns went out with it. It builds its own payload and strips those columns first now, and routes to several destinations so summary figures and the raw audit stream stay separate.
- Made the app usable on a tablet. Account settings and menus were built at desk width and were unusable on the floor. Rebuilt as a sliding drawer, with the interface tabs converted into scrollable pills sized for a thumb rather than a mouse pointer.
- Pulled the shared layout styling into one core stylesheet every theme builds on, so a layout fix lands in all of them at once.
- Fixed a startup ordering bug where the session was read before it was set up, throwing errors on the first render, and scrubbed leftover developer controls out of the production views.

---

## 3.2 — Tuesday, August 25, 2026
**Compliance gates, tank reconciliation, and being able to restore the data**

- **The mandatory pre-shift safety and compliance checklist.** The operator page stops rendering entirely until every item is checked. Not a warning, not a banner you can scroll past. If it can be skipped, sooner or later it gets skipped.
- **Real tank reconciliation.** Previously a reactor's level was a number somebody overwrote. Now a manager or operator enters a visual fill percentage, and the app compares it to what has actually been logged against that resin, adjusts inventory, and records the reconciliation as its own event. The difference between the two figures is information, and overwriting the number threw it away every time.
- The mid-shift role and station transfer tool, so a manager can move someone to a different pump or change their role during a shift and have the screen update immediately, rather than the person logging out and back in. Shift changes on the floor happen constantly, and the app was treating them as an exception.
- Managers can correct records after the fact, with work-order totals recalculating down the chain rather than a fixed total drifting away from the logs it summarises.
- One-click database backups, a real dump to a dedicated folder, plus the restore path. This was the point where the app held data that only existed there, so being able to get it back stopped being optional. The backup target had a bug that was not found until the 29th.

---

## 3.1 — Monday, August 24, 2026
**Analytics, theming, and a way to talk to the floor**

- **The Analytics Hub.** Downtime causes ranked so the top few are obvious rather than buried in a list, rolling performance windows, output trendlines, and a per-operator heatmap. The plant already had all this information. It just lived in whoever happened to remember it.
- **The live pace engine** on top of that. Current rate against target, projected end-of-shift output, and the gap between them, recalculated as logs come in. Knowing at hour three that you are going to miss by 200 is worth a lot more than knowing at hour eight that you did.
- The theming system, a multi-theme design layer with responsive layout rather than one fixed set of colours. Part of that is that a screen in a bright pouring area and a screen at a desk want different things. Part of it is that people use software more willingly when it does not feel imposed on them.
- Automatic shift handover reports, a generated PDF emailed to a list at the end of a shift with nobody having to remember. Handover was being done verbally and inconsistently, so what the next shift knew depended entirely on who was standing there. Removed on September 4th, see 3.12.
- Floor comms, direct messaging between plant leadership and floor staff inside the app. The alternative was walking across the plant or hoping someone saw a text. Renamed and honestly labelled on September 7th, see 3.24.

---

## 3.0 — Sunday, August 23, 2026
**The foundation**

- **Moved the core data out of ad hoc files and into a real Postgres database.** Everything else rests on this one. File-based storage falls apart the moment two people log at the same time, and on a floor with multiple pumps that is the normal case rather than the edge case.
- **Laid out the core tables** the whole app has been built on since. Production logs, downtime, assigned runs, reactors, resin specs, pump stations, cleanliness audits and users. I spent the time getting their shape right before building screens over them, because tables are the part that is painful to change later. That mostly held up. Everything added since has been additive.
- Seeded the baseline reference data so a fresh install boots into something usable rather than a set of empty dropdowns.
- Set up the three surfaces the app still has, the operator workstation, the management side and the live display views, and the routing between them.
- Added server-side photo storage for cleanliness checks and incident reports, saved with the record they belong to instead of living as email attachments and photos on people's phones. A photo nobody can find later does not prove anything.
